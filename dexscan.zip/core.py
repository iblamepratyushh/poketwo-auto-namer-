"""core.py - pure logic (no discord import): parsing Pokétwo messages, name resolution, ping building."""
from __future__ import annotations

import json
import os
import re
import unicodedata
from dataclasses import dataclass, field
from typing import Optional

POKETWO_ID = int(os.getenv("POKETWO_ID", "716390085896962058"))

REGIONS = ["kanto", "johto", "hoenn", "sinnoh", "unova", "kalos", "alola", "galar", "paldea"]   # gen 1..9
TYPES = ["normal", "fire", "water", "electric", "grass", "ice", "fighting", "poison", "ground", "flying",
         "psychic", "bug", "rock", "ghost", "dragon", "dark", "steel", "fairy"]
RARITIES = ["legendary", "mythical", "ultrabeast", "paradox"]

ULTRA_BEASTS = {"nihilego", "buzzwole", "pheromosa", "xurkitree", "celesteela", "kartana", "guzzlord",
                "poipole", "naganadel", "stakataka", "blacephalon"}
PARADOX = {"great tusk", "scream tail", "brute bonnet", "flutter mane", "slither wing", "sandy shocks",
           "roaring moon", "walking wake", "gouging fire", "raging bolt", "iron treads", "iron bundle",
           "iron hands", "iron jugulis", "iron moth", "iron thorns", "iron valiant", "iron leaves",
           "iron boulder", "iron crown"}
REGIONAL_PREFIXES = ("alolan", "galarian", "hisuian", "paldean")
HIGH_IV, LOW_IV = 90.0, 10.0          # only used if the catch message exposes an IV %

SPAWN_TITLE_RE = re.compile(r"wild\s+pok[eé]mon\s+has\s+appeared", re.I)
CATCH_RE = re.compile(
    r"Congratulations\s+<@!?(\d+)>!?\s+You\s+caught\s+a\s+Level\s+(\d+)\s+(?P<name>.+?)"
    r"(?:\s*<a?:\w+:\d+>|\s*\(\d+(?:\.\d+)?%\))*\s*!", re.I)
IV_RE = re.compile(r"\((\d+(?:\.\d+)?)%\)")
SHINY_RE = re.compile(r"colou?rs\s+seem\s+unusual", re.I)
HINT_RE = re.compile(r"The\s+pok[eé]mon\s+is\s+(?P<hint>[^\n]+?)\.?\s*$", re.I)


def norm(s: str) -> str:
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = s.lower().replace("’", "'")
    s = re.sub(r"[.':’\"`*_~]", "", s)
    s = re.sub(r"[\s\-]+", " ", s).strip()
    return s


def ordinal(n: int) -> str:
    return f"{n}{'th' if 10 <= n % 100 <= 20 else {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th')}"


def is_spawn_title(title: Optional[str]) -> bool:
    return bool(title and SPAWN_TITLE_RE.search(title))


@dataclass
class Catch:
    user_id: int
    level: int
    name: str
    shiny: bool
    iv: Optional[float]


def parse_catch(content: str) -> Optional[Catch]:
    m = CATCH_RE.search(content or "")
    if not m:
        return None
    iv = IV_RE.search(content[m.start():m.end()])
    return Catch(int(m.group(1)), int(m.group(2)), m.group("name").strip(" *_"),
                 bool(SHINY_RE.search(content)), float(iv.group(1)) if iv else None)


def hint_pattern(content: str) -> Optional[re.Pattern]:
    """Turn Pokétwo's 'The pokémon is b\\_\\_\\_saur.' into a regex."""
    m = HINT_RE.search((content or "").strip())
    if not m:
        return None
    h = m.group("hint").replace("\\", "").strip()
    if "_" not in h:
        return None
    pat = "".join("." if c == "_" else re.escape(c.lower()) for c in h)
    return re.compile(f"^{pat}$")


def shiny_odds(chain: int) -> float:
    """Approximation of Pokétwo's shiny-chain odds: 1/4096 scaled by (1 + chain/30)."""
    return min(1.0, (1 + max(0, chain) / 30) / 4096)


def high_low_iv(iv: Optional[float]) -> Optional[str]:
    if iv is None:
        return None
    return "high_iv" if iv >= HIGH_IV else "low_iv" if iv <= LOW_IV else None


# ----------------------------------------------------------------- pokédex ---
@dataclass
class Meta:
    name: str
    gen: int = 0
    types: list = field(default_factory=list)
    legendary: bool = False
    mythical: bool = False
    names: dict = field(default_factory=dict)       # de / fr / ja / romaji

    @property
    def n(self) -> str:
        return norm(self.name)

    @property
    def base(self) -> str:
        n = self.n
        for p in (*REGIONAL_PREFIXES, "gigantamax", "mega", "primal"):
            if n.startswith(p + " "):
                return n[len(p) + 1:]
        return n

    @property
    def regional(self) -> bool:
        return self.n.split(" ")[0] in REGIONAL_PREFIXES

    @property
    def gmax(self) -> bool:
        return self.n.startswith("gigantamax ")

    @property
    def ultrabeast(self) -> bool:
        return self.base in ULTRA_BEASTS

    @property
    def paradox(self) -> bool:
        return self.base in PARADOX

    @property
    def rarities(self) -> list:
        return [r for r, ok in (("legendary", self.legendary), ("mythical", self.mythical),
                                ("ultrabeast", self.ultrabeast), ("paradox", self.paradox)) if ok]

    @property
    def is_rare(self) -> bool:      # docs: rare = legendary, mythical, Ultra Beast (paradox has its own ping)
        return self.legendary or self.mythical or self.ultrabeast

    @property
    def region(self) -> Optional[str]:
        return REGIONS[self.gen - 1] if 1 <= self.gen <= len(REGIONS) else None


class Pokedex:
    def __init__(self, sprite_names: list, entries: list):
        raw = {e["name"]: e for e in entries}
        self.meta: dict = {}
        self.lookup: dict = {}
        for name in sprite_names:
            d = raw.get(name, {})
            m = Meta(name, d.get("gen", 0), d.get("types", []), d.get("legendary", False),
                     d.get("mythical", False), d.get("names", {}))
            self.meta[name] = m
            self.lookup.setdefault(m.n, name)
        for name, m in self.meta.items():                      # aliases never override exact names
            for a in self._aliases(m):
                self.lookup.setdefault(a, name)

    @staticmethod
    def _aliases(m: Meta) -> set:
        out = {norm(v) for v in m.names.values() if v}
        n = m.n
        for pfx, short in (("alolan", "alola"), ("galarian", "galar"), ("hisuian", "hisui"), ("paldean", "paldea")):
            if n.startswith(pfx + " "):
                b = n[len(pfx) + 1:]
                out |= {f"{short} {b}", f"{b} {short}", f"{b} {pfx}"}
        if n.startswith("gigantamax "):
            b = n[11:]
            out |= {f"gmax {b}", f"{b} gmax", f"{b} gigantamax"}
        return out

    def resolve(self, text: str) -> Optional[str]:
        return self.lookup.get(norm(text))


# --------------------------------------------------------------- ping logic ---
@dataclass
class Pings:
    sh: list = field(default_factory=list)
    cl: list = field(default_factory=list)
    q_region: list = field(default_factory=list)
    q_type: list = field(default_factory=list)
    q_rarity: list = field(default_factory=list)
    roles: list = field(default_factory=list)       # (label, role_id)

    @property
    def owners(self) -> set:
        return set(self.sh) | set(self.cl)


def _dedupe(seq, seen: set) -> list:
    out = []
    for u in seq:
        if u not in seen:
            seen.add(u); out.append(u)
    return out


def compute_pings(db, meta: Meta, gid: int, cid: int, is_member, include_afk=False) -> Pings:
    """is_member(uid)->bool filters users who left. AFK users skipped (unless include_afk)."""
    ok = lambda u: is_member(u) and (include_afk or not db.is_afk(u))
    p, seen = Pings(), set()
    name = meta.name
    if db.cflag(cid, "sh"):
        us = [r["user_id"] for r in db.q("SELECT user_id FROM hunts WHERE guild_id=? AND pokemon=?", (gid, name))]
        us += [r["user_id"] for r in db.q("SELECT user_id FROM global_hunt WHERE pokemon=?", (name,))
               if not db.is_global_off(r["user_id"], gid)]
        p.sh = _dedupe([u for u in us if ok(u)], seen)
    if db.cflag(cid, "collection"):
        us = [r["user_id"] for r in db.q("SELECT user_id FROM collection WHERE guild_id=? AND pokemon=?", (gid, name))]
        us += [r["user_id"] for r in db.q("SELECT user_id FROM collection WHERE guild_id=0 AND pokemon=?", (name,))
               if not db.is_global_off(r["user_id"], gid)]
        p.cl = _dedupe([u for u in us if ok(u)], seen)
    if db.cflag(cid, "questping"):
        qs = set()
        if meta.region:
            p.q_region = _dedupe([u for u in db.quest_users(gid, "region", meta.region) if ok(u)], qs)
        for t in meta.types:
            p.q_type += [u for u in db.quest_users(gid, "type", t) if ok(u) and u not in set(p.q_type)]
        for r in meta.rarities:
            p.q_rarity += [u for u in db.quest_users(gid, "rarity", r) if ok(u) and u not in set(p.q_rarity)]
    cfg = db.cfg(gid)
    if meta.is_rare and cfg.get("rare_role") and db.cflag(cid, "rareping"):
        p.roles.append(("Rare Ping", cfg["rare_role"]))
    if meta.paradox and cfg.get("paradox_role") and db.cflag(cid, "paradoxping"):
        p.roles.append(("Paradox Ping", cfg["paradox_role"]))
    if meta.regional and cfg.get("regional_role") and db.cflag(cid, "regionalping"):
        p.roles.append(("Regional Ping", cfg["regional_role"]))
    return p


def format_pings(p: Pings) -> str:
    lines = []
    m = lambda ids: " ".join(f"<@{u}>" for u in ids)
    if p.sh: lines.append(f"✨ **Shiny Hunt Pings:** {m(p.sh)}")
    if p.cl: lines.append(f"**Collection Pings:** {m(p.cl)}")
    if p.q_region: lines.append(f"**Quest Pings (Regional):** {m(p.q_region)}")
    if p.q_type: lines.append(f"**Quest Pings (Types):** {m(p.q_type)}")
    if p.q_rarity: lines.append(f"**Quest Pings (Rarity):** {m(p.q_rarity)}")
    for label, rid in p.roles: lines.append(f"**{label}:** <@&{rid}>")
    return "\n".join(lines)


def chunk_text(text: str, limit: int = 1900) -> list:
    """Split on line boundaries, then on spaces, never exceeding limit."""
    out, cur = [], ""
    for line in text.split("\n"):
        while len(line) > limit:
            cut = line.rfind(" ", 0, limit); cut = cut if cut > 0 else limit
            if cur: out.append(cur); cur = ""
            out.append(line[:cut]); line = line[cut:].lstrip()
        if len(cur) + len(line) + 1 > limit and cur:
            out.append(cur); cur = ""
        cur = f"{cur}\n{line}" if cur else line
    if cur: out.append(cur)
    return out


def fmt_duration(sec: int) -> str:
    for unit, n in (("day", 86400), ("hour", 3600), ("minute", 60), ("second", 1)):
        if sec >= n and sec % n == 0:
            v = sec // n; return f"{v} {unit}{'s' if v != 1 else ''}"
    return f"{sec} seconds"


def categories_for_spawn(meta: Meta) -> list:
    cats = []
    if meta.gmax: cats.append("gigantamax")
    if meta.is_rare or meta.paradox: cats.append("rare")
    if meta.regional: cats.append("regional")
    return cats


# ------------------------------------------------- spawn state / steal logic ---
@dataclass
class SpawnState:
    name: str
    msg_id: int
    owners: dict = field(default_factory=lambda: {"sh": set(), "cl": set()})
    timer_kind: Optional[str] = None        # "sh" / "cl" when a timer is running for this spawn
    timer_end: Optional[float] = None
    task: object = None

    @property
    def all_owners(self) -> set:
        return self.owners["sh"] | self.owners["cl"]


KIND_LABEL = {"sh": "Shiny Hunt", "cl": "Collection"}
STEAL_FLAG = {"sh": "shstealwarn", "cl": "clstealwarn"}


def names_match(a: str, b: str, resolve=None) -> bool:
    if resolve:
        ra, rb = resolve(a), resolve(b)
        if ra and rb:
            return ra == rb
    return norm(a) == norm(b)


def steal_kind(state: Optional[SpawnState], catcher_id: int, caught_name: str, now: float, resolve=None) -> Optional[str]:
    """'sh' / 'cl' if this catch is a steal, else None.
    Timer running  -> only owners of the timer's kind may catch before it ends; after it ends anyone may.
    No timer       -> any owner (sh or cl) may catch; everyone else is stealing."""
    if not state or not names_match(state.name, caught_name, resolve) or not state.all_owners:
        return None
    if state.timer_kind:
        if state.timer_end is None or now >= state.timer_end:
            return None
        return None if catcher_id in state.owners[state.timer_kind] else state.timer_kind
    if catcher_id in state.all_owners:
        return None
    return "sh" if state.owners["sh"] else "cl"


def warning_text(kind: str, case: int, catcher_id: int, mon: str, owner_ids, level: int,
                 minutes: Optional[int], applied: Optional[bool]) -> str:
    owners = sorted(owner_ids)
    shown = " ".join(f"<@{u}>" for u in owners[:12]) + (f" +{len(owners) - 12} more" if len(owners) > 12 else "")
    if minutes is None:
        action = "Action taken: none."
    elif applied:
        action = f"Action taken: timed out for **{fmt_duration(minutes * 60)}**."
    else:
        action = (f"⚠️ A timeout of {fmt_duration(minutes * 60)} was due, but I couldn't apply it "
                  f"(I need **Moderate Members** and a role above theirs).")
    return (f"⚠️ **{KIND_LABEL[kind]} Steal Warning** · Case `#{case}`\n"
            f"<@{catcher_id}> caught **{mon}** while it was reserved for {shown}.\n"
            f"This is their **{ordinal(level)}** warning.\n{action}")


def solve_hint(pat, names, limit: int = 8) -> list:
    return [n for n in names if pat.match(n.lower())][:limit]
