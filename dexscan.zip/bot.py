"""bot.py - Dexscan (Pokéname-style Pokétwo namer). Batch 1: naming, shiny/collection/quest pings, core commands."""
import asyncio, collections, datetime as dt, logging, os, time
from typing import Literal

import aiohttp
import discord
from discord.ext import commands
from dotenv import load_dotenv

import sources
from core import (POKETWO_ID, RARITIES, REGIONS, STEAL_FLAG, TYPES, Pokedex, SpawnState, chunk_text, compute_pings,
                  Pings, format_pings, hint_pattern, is_spawn_title, names_match, parse_catch, shiny_odds,
                  solve_hint, steal_kind, warning_text)
from db import CHANNEL_FLAG_DEFAULTS, GUILD_FLAG_DEFAULTS, Database
from dexscan_engine import Dexscan

load_dotenv()
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("dexscan")
TOKEN = os.getenv("DISCORD_TOKEN") or os.getenv("TOKEN") or os.getenv("BOT_TOKEN")
FP_CACHE = os.getenv("FP_CACHE", "fingerprints.npz")
LEARN_DIR = os.getenv("LEARN_DIR", "learned")
CHANNEL_TOGGLES, GUILD_TOGGLES = set(CHANNEL_FLAG_DEFAULTS), set(GUILD_FLAG_DEFAULTS)


class DexBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True      # enable in the developer portal
        intents.members = True              # enable in the developer portal
        super().__init__(command_prefix=self._prefix, intents=intents, help_command=None, case_insensitive=True)
        self.db = Database(os.getenv("DB_PATH", "dexscan.db"))
        self.seen = collections.deque(maxlen=1000)
        self.times = collections.deque(maxlen=200)
        self.started = time.time()
        self.engine = self.dex = self.session = None
        self.urls: dict = {}
        self.spawns: dict = {}      # channel_id -> SpawnState
        self.manual_cd: dict = {}   # channel_id -> last manual-sh time
        self.last_spawn: dict = {}  # channel_id -> {data, named, caught, ts}  (for `learn`)

    async def _prefix(self, bot, msg):
        base = self.db.get_prefix(msg.guild.id) if msg.guild else "-"
        return commands.when_mentioned_or(base)(bot, msg)

    async def setup_hook(self):
        self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15))
        entries, sprites = await sources.load_all(self.session)      # your GitHub repo (or PokéAPI fallback)
        self.engine = await asyncio.to_thread(Dexscan.from_sprites, sprites, FP_CACHE)
        await asyncio.to_thread(self.engine.load_learned, LEARN_DIR)
        by_name = {e["name"]: e for e in entries}
        self.dex = Pokedex(self.engine.names, [by_name[n] for n in self.engine.names if n in by_name])
        self.urls = {e["name"]: e.get("thumb") or sources.sprite_url(e) for e in entries}
        await self.tree.sync()
        log.info("ready: %d pokémon loaded", len(self.engine.names))

    async def close(self):
        if self.session:
            await self.session.close()
        await super().close()

    # ---------------------------------------------------------------- events
    async def on_message(self, m: discord.Message):
        if m.author.id == POKETWO_ID:
            if m.guild:
                try:
                    if m.embeds:
                        await self.on_spawn(m)
                    if m.content:
                        await self.on_catch(m)
                        await self.on_hint(m)
                except Exception:
                    log.exception("Pokétwo message handling failed")
            return
        if m.author.bot:
            return
        ctx = await self.get_context(m)
        if ctx.valid:
            await self.invoke(ctx)
        elif m.guild:
            try:
                await self.manual_sh(m)
            except Exception:
                log.exception("manual sh failed")

    async def learn(self, cid: int, text) -> str:
        ls = self.last_spawn.get(cid)
        if not ls or time.time() - ls["ts"] > 1800:
            return "❌ I have no recent spawn image for this channel (I keep the latest one for 30 minutes)."
        name = self.dex.resolve(text) if text else (self.dex.resolve(ls["caught"]) if ls.get("caught") else None)
        if text and not name:
            return f"❌ I don't know a Pokémon called **{discord.utils.escape_markdown(text)[:60]}**."
        if not name:
            return "❓ I don't know what that spawn was yet. Wait for someone to catch it, or use `l <pokemon>`."
        ok, msg = await asyncio.to_thread(self.engine.add_template, name, ls["data"], LEARN_DIR)
        return f"🧠 Saved the exact image — {msg}" if ok else f"❌ {msg}"

    async def on_hint(self, m: discord.Message):
        if not self.db.gflag(m.guild.id, "hint"):
            return
        pat = hint_pattern(m.content)
        hits = solve_hint(pat, self.engine.names) if pat else []
        if hits:
            await m.channel.send(", ".join(f"**{h}**" for h in hits[:5]), allowed_mentions=discord.AllowedMentions.none())

    async def manual_sh(self, m: discord.Message):
        """Typing a Pokémon's name pings its shiny hunters (only where `toggle manualsh` is on)."""
        gid, cid = m.guild.id, m.channel.id
        if len(m.content) > 40 or not self.db.cflag(cid, "manualsh"):
            return
        n = self.dex.resolve(m.content)
        if not n or time.time() - self.manual_cd.get(cid, 0) < 10:
            return
        self.manual_cd[cid] = time.time()
        p = compute_pings(self.db, self.dex.meta[n], gid, cid, lambda u: m.guild.get_member(u) is not None)
        text = format_pings(Pings(sh=p.sh))
        for part in chunk_text(text) if text else []:
            await m.channel.send(part, allowed_mentions=discord.AllowedMentions(users=True))

    async def on_spawn(self, m: discord.Message):
        emb = next((e for e in m.embeds if is_spawn_title(e.title) and e.image and e.image.url), None)
        if not emb or m.id in self.seen or not self.db.cflag(m.channel.id, "spawns"):
            return
        self.seen.append(m.id)
        t0 = time.perf_counter()
        async with self.session.get(emb.image.url) as r:
            if r.status != 200:
                return
            data = await r.content.read(8_000_000)
        ls = self.last_spawn[m.channel.id] = {"data": data, "named": None, "caught": None, "ts": time.time()}
        match = await asyncio.to_thread(self.engine.identify, data)
        if not match:
            log.info("no confident match for spawn %s (stayed silent)", m.id)
            return
        meta = self.dex.meta[match.name]
        ls["named"] = match.name
        log.info("named %s via %s in %.0fms", match.name, match.how, (time.perf_counter() - t0) * 1000)
        gid, cid = m.guild.id, m.channel.id
        if self.db.gflag(gid, "textnaming"):
            await m.channel.send(f"**{meta.name}**", allowed_mentions=discord.AllowedMentions.none())
        else:
            e = discord.Embed(title=meta.name, color=0x5865F2)
            e.set_thumbnail(url=self.urls.get(meta.name, ""))
            if self.db.gflag(gid, "alts"):
                alts = [f"{k}: {v}" for k, v in meta.names.items() if v]
                if alts:
                    e.add_field(name="Alt names", value="\n".join(alts), inline=False)
            await m.channel.send(embed=e, allowed_mentions=discord.AllowedMentions.none())
        if self.db.cflag(cid, "catchcommand"):
            await m.channel.send(f"`@Pokétwo catch {meta.name.lower()}`", allowed_mentions=discord.AllowedMentions.none())
        self.times.append((time.perf_counter() - t0) * 1000)
        self.db.bump("names")
        pings = compute_pings(self.db, meta, gid, cid, lambda u: m.guild.get_member(u) is not None,
                              include_afk=False)
        self.clear_spawn(cid)
        state, kind, secs = None, None, 0
        if pings.owners:
            state = SpawnState(meta.name, m.id, {"sh": set(pings.sh), "cl": set(pings.cl)})
            kind = ("sh" if pings.sh and self.db.cflag(cid, "shtimer")
                    else "cl" if pings.cl and self.db.cflag(cid, "cltimer") else None)
            if kind:
                secs = int(self.db.cval(cid, f"{kind}timer_secs", 30))
                state.timer_kind, state.timer_end = kind, time.time() + secs
            self.spawns[cid] = state          # registered BEFORE pinging so a fast catch is still matched
        text = format_pings(pings)
        for part in chunk_text(text) if text else []:
            await m.channel.send(part, allowed_mentions=discord.AllowedMentions(users=True, roles=True))
        if state and kind:
            state.timer_end = time.time() + secs
            state.task = asyncio.create_task(self.run_timer(m.channel, state, kind, secs))

    def clear_spawn(self, cid: int):
        st = self.spawns.pop(cid, None)
        if st and st.task and not st.task.done():
            st.task.cancel()

    async def run_timer(self, channel, state: SpawnState, kind: str, secs: int):
        label = "Sh" if kind == "sh" else "Cl"
        try:
            await channel.send(f"⏳ **{label} Timer will end in {secs} seconds**")
            await asyncio.sleep(secs)
            if self.spawns.get(channel.id) is state:      # not caught / replaced meanwhile
                await channel.send(f"✅ **{label} Timer has ended! You can catch the pokemon now!**")
        except asyncio.CancelledError:
            raise
        except discord.HTTPException:
            log.warning("timer message failed in channel %s", channel.id)

    async def on_catch(self, m: discord.Message):
        c = parse_catch(m.content)
        ls = self.last_spawn.get(m.channel.id)
        if c and ls:
            ls["caught"] = c.name                      # the real name, straight from Pokétwo - used by `learn`
        st = self.spawns.get(m.channel.id)
        if not c or not st or not names_match(st.name, c.name, self.dex.resolve):
            return
        kind = steal_kind(st, c.user_id, c.name, time.time(), self.dex.resolve)
        self.clear_spawn(m.channel.id)                    # the spawn is gone either way
        if not kind or not self.db.gflag(m.guild.id, STEAL_FLAG[kind]):
            return
        member = m.guild.get_member(c.user_id)
        if member is not None and member.bot:
            return
        gid = m.guild.id
        case, level = self.db.add_warning(gid, c.user_id, kind, st.name, m.channel.id)
        minutes, applied = self.db.timeouts(gid).get(level), None
        if minutes is not None:
            applied = False
            if member is not None:
                try:
                    await member.timeout(dt.timedelta(minutes=min(minutes, 40320)),
                                         reason=f"Dexscan: {kind} steal warning #{level} (case {case})")
                    applied = True
                except (discord.Forbidden, discord.HTTPException):
                    log.warning("could not time out %s in guild %s", c.user_id, gid)
        owners = st.owners[st.timer_kind] if st.timer_kind else st.all_owners
        await m.channel.send(warning_text(kind, case, c.user_id, st.name, owners, level, minutes, applied),
                             allowed_mentions=discord.AllowedMentions(users=[discord.Object(id=c.user_id)]))


bot = DexBot()


# ------------------------------------------------------------------ helpers ---
def can_manage(member: discord.Member) -> bool:
    p = member.guild_permissions
    rid = bot.db.cfg(member.guild.id).get("manager_role")
    return p.administrator or p.manage_guild or bool(rid and any(r.id == rid for r in member.roles))


def admin_only():
    async def pred(ctx):
        if not ctx.guild:
            raise commands.NoPrivateMessage()
        if can_manage(ctx.author):
            return True
        raise commands.CheckFailure("You need **Manage Server** (or the bot manager role) for that.")
    return commands.check(pred)


def resolve(text: str):
    return bot.dex.resolve(text)


async def not_found(ctx, text):
    await ctx.send(f"❌ I don't know a Pokémon called **{discord.utils.escape_markdown(text)[:60]}**.")


# ----------------------------------------------------------------- commands ---
@bot.hybrid_command(name="help", description="Show the command list")
async def help_cmd(ctx):
    p = bot.db.get_prefix(ctx.guild.id) if ctx.guild else "-"
    e = discord.Embed(title="Dexscan — commands", color=0x5865F2, description=f"Prefix: `{p}` (slash commands work too)")
    e.add_field(name="Shiny hunt", value="`shinyhunt <pokemon>` · `removeshinyhunt <pokemon>` · `myshinyhunt` · `globalsh [pokemon]`", inline=False)
    e.add_field(name="Collection", value="`collection add|remove|list|clear` · `globalcollection add|remove|list|clear`", inline=False)
    e.add_field(name="Quest pings", value="`questpings` (`qp`) — regions, types, rarity", inline=False)
    e.add_field(name="Timers & steals", value="`shtimer [3-180]` · `collectiontimer [3-180]` · `warnings [member]` · `deletewarn <case>` · `settimeout <level> <min>` · `unsettimeout <level>` · `timeouts`", inline=False)
    e.add_field(name="Learning", value="`@Dexscan l` (or `/dexscan l`) right after a catch saves that spawn image so it's never missed · `l <pokemon>` if you know the name · `unlearn <pokemon>`", inline=False)
    e.add_field(name="Tags", value="`tags <pokemon>` · `alltags` · `removetags [member]`", inline=False)
    e.add_field(name="Server", value="`toggle <feature>` · `setprefix <p>` · `serversettings` · `channelsettings` · `rareping|paradoxping|regionalping [@role]` · `managerrole @role` · `removemanagerrole` · `afk` · `shinyrate [chain]`", inline=False)
    e.add_field(name="Info", value="`ping`", inline=False)
    await ctx.send(embed=e)


@bot.hybrid_command(name="ping", description="Latency and naming speed")
async def ping(ctx):
    avg = sum(bot.times) / len(bot.times) if bot.times else 0
    await ctx.send(f"🏓 websocket `{bot.latency*1000:.0f}ms` · avg naming `{avg:.0f}ms` · database `{bot.db.ping():.1f}ms`")


@bot.hybrid_command(name="setprefix", description="Change the command prefix")
@admin_only()
async def setprefix(ctx, new_prefix: str):
    if not 1 <= len(new_prefix) <= 5 or new_prefix.isspace():
        return await ctx.send("❌ Prefix must be 1–5 visible characters.")
    bot.db.set_cfg(ctx.guild.id, prefix=new_prefix)
    await ctx.send(f"✅ Prefix is now `{new_prefix}`")


@bot.hybrid_command(name="toggle", description="Enable/disable a feature")
@admin_only()
async def toggle(ctx, feature: str = None):
    allf = sorted(CHANNEL_TOGGLES | GUILD_TOGGLES)
    if not feature or feature.lower() not in allf:
        return await ctx.send("Features: " + ", ".join(f"`{f}`" for f in allf))
    f = feature.lower()
    if f in CHANNEL_TOGGLES:
        v = not bot.db.cflag(ctx.channel.id, f); bot.db.set_cflag(ctx.channel.id, f, v); scope = "in this channel"
    else:
        v = not bot.db.gflag(ctx.guild.id, f); bot.db.set_gflag(ctx.guild.id, f, v); scope = "server-wide"
    await ctx.send(f"{'✅ Enabled' if v else '⛔ Disabled'} `{f}` {scope}.")


@bot.hybrid_command(name="shinyhunt", aliases=["sh"], description="Set your shiny hunt for this server")
@commands.guild_only()
async def shinyhunt(ctx, *, pokemon: str):
    n = resolve(pokemon)
    if not n:
        return await not_found(ctx, pokemon)
    bot.db.set_hunt(ctx.guild.id, ctx.author.id, n)
    await ctx.send(f"✨ Now shiny hunting **{n}** in this server.")


@bot.hybrid_command(name="removeshinyhunt", aliases=["rsh"], description="Stop hunting a Pokémon here")
@commands.guild_only()
async def removeshinyhunt(ctx, *, pokemon: str):
    n = resolve(pokemon)
    if not n:
        return await not_found(ctx, pokemon)
    ok = bot.db.remove_hunt(ctx.guild.id, ctx.author.id, n)
    await ctx.send(f"✅ Removed your **{n}** hunt." if ok else f"You weren't hunting **{n}** here.")


@bot.hybrid_command(name="myshinyhunt", aliases=["mysh"], description="Show your shiny hunt here")
@commands.guild_only()
async def myshinyhunt(ctx):
    h = bot.db.get_hunt(ctx.guild.id, ctx.author.id)
    await ctx.send(f"✨ You're hunting **{h}** in this server." if h else "You have no shiny hunt in this server.")


@bot.hybrid_command(name="globalsh", aliases=["gsh", "globalshinyhunt"], description="Your global shiny hunt (all servers)")
async def globalsh(ctx, *, pokemon: str = None):
    if not pokemon:
        h = bot.db.get_global_hunt(ctx.author.id)
        return await ctx.send(f"🌐 Global hunt: **{h}**" if h else "You have no global hunt. Use `globalsh <pokemon>`.")
    if pokemon.lower() in ("off", "clear", "remove"):
        bot.db.clear_global_hunt(ctx.author.id)
        return await ctx.send("✅ Global hunt cleared.")
    n = resolve(pokemon)
    if not n:
        return await not_found(ctx, pokemon)
    bot.db.set_global_hunt(ctx.author.id, n)
    await ctx.send(f"🌐 Global shiny hunt set to **{n}** (replaces your previous one).")


async def _coll(ctx, gid: int, action: str, pokemon: str):
    uid, db, label = ctx.author.id, bot.db, "global collection" if gid == 0 else "collection"
    if action in ("add", "remove"):
        if not pokemon:
            return await ctx.send(f"Usage: `{action} <pokemon>`")
        n = resolve(pokemon)
        if not n:
            return await not_found(ctx, pokemon)
        if action == "remove":
            ok = db.coll_remove(gid, uid, n)
            return await ctx.send(f"✅ Removed **{n}**." if ok else f"**{n}** isn't in your {label}.")
        if ctx.guild:
            meta = bot.dex.meta[n]
            if meta.is_rare and not db.gflag(ctx.guild.id, "rarecollect"):
                return await ctx.send("❌ Rare Pokémon can't be added in this server.")
            cfg = db.cfg(ctx.guild.id); lim = cfg.get("collection_limit")
            if lim is not None and len(db.coll_list(gid, uid)) >= lim and n not in db.coll_list(gid, uid):
                return await ctx.send(f"❌ Collection limit reached ({lim}).")
        added = db.coll_add(gid, uid, n)
        return await ctx.send(f"✅ Added **{n}** to your {label}." if added else f"**{n}** is already in your {label}.")
    if action == "list":
        lst = db.coll_list(gid, uid)
        if not lst:
            return await ctx.send(f"Your {label} is empty.")
        for part in chunk_text(f"📋 **Your {label}** ({len(lst)}): " + ", ".join(lst)):
            await ctx.send(part)
        return
    if action == "clear":
        await ctx.send(f"🧹 Cleared {db.coll_clear(gid, uid)} Pokémon from your {label}.")
        return
    await ctx.send("Subcommands: `add`, `remove`, `list`, `clear`")


@bot.hybrid_command(name="collection", aliases=["cl"], description="Manage your server collection list")
@commands.guild_only()
async def collection(ctx, action: str = "list", *, pokemon: str = None):
    await _coll(ctx, ctx.guild.id, action.lower(), pokemon)


@bot.hybrid_command(name="globalcollection", aliases=["globalcol", "gc", "gcl", "globalcl"],
                    description="Manage your global collection list")
async def globalcollection(ctx, action: str = "list", *, pokemon: str = None):
    await _coll(ctx, 0, action.lower(), pokemon)


@bot.hybrid_command(name="afk", description="Pause all pings from every server")
async def afk(ctx):
    on = bot.db.toggle_afk(ctx.author.id)
    await ctx.send("😴 You're AFK — no pings." if on else "👋 Welcome back — pings resumed.")


# ------------------------------------------------------------- quest pings UI ---
RARITY_LABEL = {"legendary": "Legendary", "mythical": "Mythical", "ultrabeast": "Ultra Beast", "paradox": "Paradox"}


class QuestSelect(discord.ui.Select):
    def __init__(self, kind: str, placeholder: str, values: list, current: set):
        opts = [discord.SelectOption(label=RARITY_LABEL.get(v, v.title()), value=v, default=v in current) for v in values]
        super().__init__(placeholder=placeholder, min_values=0, max_values=len(opts), options=opts)
        self.kind = kind

    async def callback(self, interaction: discord.Interaction):
        v: "QuestView" = self.view
        bot.db.quest_set(v.gid, v.uid, self.kind, self.values)
        for o in self.options:
            o.default = o.value in self.values
        await interaction.response.edit_message(embed=v.embed(), view=v)


class QuestView(discord.ui.View):
    def __init__(self, gid: int, uid: int):
        super().__init__(timeout=300)
        self.gid, self.uid, self.message = gid, uid, None
        cur = bot.db.quest_get(gid, uid)
        self.add_item(QuestSelect("region", "Regions", REGIONS, cur.get("region", set())))
        self.add_item(QuestSelect("type", "Types", TYPES, cur.get("type", set())))
        self.add_item(QuestSelect("rarity", "Rarity tiers", RARITIES, cur.get("rarity", set())))

    def embed(self) -> discord.Embed:
        cur = bot.db.quest_get(self.gid, self.uid)
        show = lambda k, order: ", ".join(RARITY_LABEL.get(x, x.title()) for x in order if x in cur.get(k, set())) or "—"
        e = discord.Embed(title="Quest pings", color=0x5865F2,
                          description="Pick what you want to be pinged for in this server. Changes save instantly.")
        e.add_field(name="Regions", value=show("region", REGIONS), inline=False)
        e.add_field(name="Types", value=show("type", TYPES), inline=False)
        e.add_field(name="Rarity", value=show("rarity", RARITIES), inline=False)
        return e

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.uid:
            await interaction.response.send_message("That menu belongs to someone else — run `qp` yourself.", ephemeral=True)
            return False
        return True

    async def on_timeout(self):
        for child in self.children:
            child.disabled = True
        if self.message:
            try:
                await self.message.edit(view=self)
            except discord.HTTPException:
                pass


@bot.hybrid_command(name="questpings", aliases=["qp"], description="Choose quest pings (regions, types, rarity)")
@commands.guild_only()
async def questpings(ctx):
    v = QuestView(ctx.guild.id, ctx.author.id)
    v.message = await ctx.send(embed=v.embed(), view=v)


# ---------------------------------------------------------------- timers ---
async def _timer_cmd(ctx, kind: str, seconds):
    cid, flag, name = ctx.channel.id, f"{kind}timer", "shtimer" if kind == "sh" else "collectiontimer"
    nice = "Shiny hunt" if kind == "sh" else "Collection"
    if seconds is None:
        cur, on = int(bot.db.cval(cid, f"{kind}timer_secs", 30)), bot.db.cflag(cid, flag)
        return await ctx.send(f"⏱️ {nice} timer in this channel: **{cur}s**, currently **{'on' if on else 'off'}**.\n"
                              f"Change: `{ctx.prefix}{name} <3-180>` · Enable/disable: `{ctx.prefix}toggle {flag}`")
    if not can_manage(ctx.author):
        raise commands.CheckFailure("You need **Manage Server** (or the bot manager role) for that.")
    bot.db.set_cval(cid, f"{kind}timer_secs", seconds)
    on = bot.db.cflag(cid, flag)
    await ctx.send(f"✅ {nice} timer set to **{seconds}s** for this channel."
                   + ("" if on else f" It's currently **off** — enable it with `{ctx.prefix}toggle {flag}`."))


@bot.hybrid_command(name="shtimer", description="Set the shiny hunt timer (3-180s) for this channel")
@commands.guild_only()
async def shtimer(ctx, seconds: commands.Range[int, 3, 180] = None):
    await _timer_cmd(ctx, "sh", seconds)


@bot.hybrid_command(name="collectiontimer", aliases=["cltimer"], description="Set the collection timer (3-180s) for this channel")
@commands.guild_only()
async def collectiontimer(ctx, seconds: commands.Range[int, 3, 180] = None):
    await _timer_cmd(ctx, "cl", seconds)


# ------------------------------------------------------ warnings / timeouts ---
@bot.hybrid_command(name="warnings", description="Show steal warnings for you or another member")
@commands.guild_only()
async def warnings(ctx, member: discord.Member = None):
    member = member or ctx.author
    if member.id != ctx.author.id and not can_manage(ctx.author):
        raise commands.CheckFailure("You can only view your own warnings.")
    rows = bot.db.warnings(ctx.guild.id, member.id)
    if not rows:
        return await ctx.send(f"✅ {member.display_name} has no warnings.")
    lines = [f"`#{r['case_id']}` · {'Shiny Hunt' if r['kind'] == 'sh' else 'Collection'} · **{r['pokemon']}** · <t:{int(r['ts'])}:R>"
             for r in rows[-25:]]
    extra = f"\n*(showing the latest 25 of {len(rows)})*" if len(rows) > 25 else ""
    await ctx.send(f"⚠️ **{len(rows)} warning(s)** for {member.display_name}\n" + "\n".join(lines) + extra,
                   allowed_mentions=discord.AllowedMentions.none())


@bot.hybrid_command(name="deletewarn", description="Delete a warning by case ID")
@admin_only()
async def deletewarn(ctx, case_id: int):
    ok = bot.db.del_warning(ctx.guild.id, case_id)
    await ctx.send(f"✅ Deleted case `#{case_id}`." if ok else f"❌ No case `#{case_id}` in this server.")


@bot.hybrid_command(name="settimeout", description="Auto-timeout a member at a warning level")
@admin_only()
async def settimeout(ctx, level: commands.Range[int, 1, 100], minutes: commands.Range[int, 1, 40320]):
    bot.db.set_timeout_level(ctx.guild.id, level, minutes)
    from core import fmt_duration
    await ctx.send(f"✅ At warning **{level}** the catcher will be timed out for **{fmt_duration(minutes * 60)}**.")


@bot.hybrid_command(name="unsettimeout", description="Remove the auto-timeout for a warning level")
@admin_only()
async def unsettimeout(ctx, level: commands.Range[int, 1, 100]):
    ok = bot.db.unset_timeout_level(ctx.guild.id, level)
    await ctx.send(f"✅ Removed the timeout for warning **{level}**." if ok else f"❌ No timeout is set for warning **{level}**.")


@bot.hybrid_command(name="timeouts", description="Show the auto-timeout levels")
@commands.guild_only()
async def timeouts(ctx):
    from core import fmt_duration
    t = bot.db.timeouts(ctx.guild.id)
    if not t:
        return await ctx.send("No auto-timeouts set. Use `settimeout <level> <minutes>`.")
    await ctx.send("⏱️ **Auto-timeouts**\n" + "\n".join(f"Warning **{l}** → {fmt_duration(m * 60)}" for l, m in t.items()))


# ------------------------------------------------------- tags / info / roles ---
NO_PING = discord.AllowedMentions.none()


@bot.hybrid_command(name="tags", description="Who is hunting / collecting a Pokémon in this server")
@commands.guild_only()
async def tags(ctx, *, pokemon: str):
    n = resolve(pokemon)
    if not n:
        return await not_found(ctx, pokemon)
    gid, db = ctx.guild.id, bot.db
    sh = [r["user_id"] for r in db.q("SELECT user_id FROM hunts WHERE guild_id=? AND pokemon=?", (gid, n))]
    cl = [r["user_id"] for r in db.q("SELECT user_id FROM collection WHERE guild_id=? AND pokemon=?", (gid, n))]
    fmt = lambda ids: " ".join(f"<@{u}>" for u in ids) or "—"
    for part in chunk_text(f"**{n}**\n✨ Shiny hunters: {fmt(sh)}\n📋 Collectors: {fmt(cl)}"):
        await ctx.send(part, allowed_mentions=NO_PING)


@bot.hybrid_command(name="alltags", description="Every shiny hunt and collection tag in this server")
@admin_only()
async def alltags(ctx):
    gid, db = ctx.guild.id, bot.db
    rows = db.q("SELECT pokemon, 'sh' AS k, user_id FROM hunts WHERE guild_id=? UNION ALL "
                "SELECT pokemon, 'cl', user_id FROM collection WHERE guild_id=?", (gid, gid))
    if not rows:
        return await ctx.send("Nobody has any tags in this server yet.")
    grouped: dict = {}
    for r in rows:
        grouped.setdefault(r["pokemon"], {"sh": [], "cl": []})[r["k"]].append(r["user_id"])
    lines = []
    for name in sorted(grouped):
        g = grouped[name]
        parts = ([f"✨ {' '.join(f'<@{u}>' for u in g['sh'])}"] if g["sh"] else []) + \
                ([f"📋 {' '.join(f'<@{u}>' for u in g['cl'])}"] if g["cl"] else [])
        lines.append(f"**{name}** — " + " · ".join(parts))
    chunks = chunk_text("\n".join(lines))
    for part in chunks[:6]:
        await ctx.send(part, allowed_mentions=NO_PING)
    if len(chunks) > 6:
        await ctx.send(f"…and {len(chunks) - 6} more page(s) — use `tags <pokemon>` for specifics.")


@bot.hybrid_command(name="removetags", description="Remove all your tags in this server (admins: any member)")
@commands.guild_only()
async def removetags(ctx, member: discord.Member = None):
    member = member or ctx.author
    if member.id != ctx.author.id and not can_manage(ctx.author):
        raise commands.CheckFailure("You can only remove your own tags.")
    n = bot.db.remove_user_tags(ctx.guild.id, member.id)
    await ctx.send(f"🧹 Removed {n} tag(s) for {member.display_name} in this server.", allowed_mentions=NO_PING)


@bot.hybrid_command(name="shinyrate", description="Approximate shiny odds for a chain length")
async def shinyrate(ctx, chain: commands.Range[int, 0, 100000] = 0):
    p = shiny_odds(chain)
    await ctx.send(f"✨ Chain **{chain}** → about **1 in {round(1 / p):,}** per spawn (~{p * 100:.3f}%). *Approximate.*")


@bot.hybrid_command(name="serversettings", description="Show this server's settings")
@commands.guild_only()
async def serversettings(ctx):
    gid, db = ctx.guild.id, bot.db
    cfg = db.cfg(gid)
    role = lambda k: f"<@&{cfg[k]}>" if cfg.get(k) else "—"
    e = discord.Embed(title=f"Settings — {ctx.guild.name}", color=0x5865F2)
    e.add_field(name="Prefix", value=f"`{db.get_prefix(gid)}`")
    e.add_field(name="Server toggles", value="\n".join(f"{'✅' if db.gflag(gid, f) else '⛔'} {f}" for f in sorted(GUILD_TOGGLES)))
    e.add_field(name="Roles", value=f"Manager: {role('manager_role')}\nRare: {role('rare_role')}\n"
                                    f"Paradox: {role('paradox_role')}\nRegional: {role('regional_role')}")
    t = db.timeouts(gid)
    e.add_field(name="Auto-timeouts", value="\n".join(f"Warning {l} → {m} min" for l, m in t.items()) or "—")
    await ctx.send(embed=e, allowed_mentions=NO_PING)


@bot.hybrid_command(name="channelsettings", description="Show this channel's settings")
@commands.guild_only()
async def channelsettings(ctx):
    cid, db = ctx.channel.id, bot.db
    e = discord.Embed(title="Channel settings", color=0x5865F2)
    e.add_field(name="Toggles", value="\n".join(f"{'✅' if db.cflag(cid, f) else '⛔'} {f}" for f in sorted(CHANNEL_TOGGLES)))
    e.add_field(name="Timers", value=f"Shiny hunt: {db.cval(cid, 'shtimer_secs', 30)}s\nCollection: {db.cval(cid, 'cltimer_secs', 30)}s")
    await ctx.send(embed=e)


async def _set_role(ctx, key: str, label: str, role):
    if not can_manage(ctx.author):
        raise commands.CheckFailure("You need **Manage Server** (or the bot manager role) for that.")
    bot.db.set_cfg(ctx.guild.id, **{key: role.id if role else None})
    await ctx.send(f"✅ {label} ping role set to {role.mention}." if role else f"✅ {label} ping role cleared.",
                   allowed_mentions=NO_PING)


@bot.hybrid_command(name="rareping", description="Role to ping for rare spawns (omit to clear)")
@commands.guild_only()
async def rareping(ctx, role: discord.Role = None):
    await _set_role(ctx, "rare_role", "Rare", role)


@bot.hybrid_command(name="paradoxping", description="Role to ping for Paradox spawns (omit to clear)")
@commands.guild_only()
async def paradoxping(ctx, role: discord.Role = None):
    await _set_role(ctx, "paradox_role", "Paradox", role)


@bot.hybrid_command(name="regionalping", description="Role to ping for regional forms (omit to clear)")
@commands.guild_only()
async def regionalping(ctx, role: discord.Role = None):
    await _set_role(ctx, "regional_role", "Regional", role)


@bot.hybrid_command(name="managerrole", description="Let a role manage the bot (needs Manage Server)")
@commands.guild_only()
async def managerrole(ctx, role: discord.Role):
    if not ctx.author.guild_permissions.manage_guild and not ctx.author.guild_permissions.administrator:
        raise commands.CheckFailure("Only members with **Manage Server** can change the manager role.")
    bot.db.set_cfg(ctx.guild.id, manager_role=role.id)
    await ctx.send(f"✅ Members with {role.mention} can now manage Dexscan.", allowed_mentions=NO_PING)


@bot.hybrid_command(name="removemanagerrole", description="Remove the bot manager role")
@commands.guild_only()
async def removemanagerrole(ctx):
    if not ctx.author.guild_permissions.manage_guild and not ctx.author.guild_permissions.administrator:
        raise commands.CheckFailure("Only members with **Manage Server** can change the manager role.")
    bot.db.set_cfg(ctx.guild.id, manager_role=None)
    await ctx.send("✅ Manager role removed.")


# --------------------------------------------------------------- learning ---
async def may_teach(member) -> bool:
    return can_manage(member) or await bot.is_owner(member)


@bot.hybrid_command(name="learn", aliases=["l"], description="Teach Dexscan the latest spawn image (name optional)")
@commands.guild_only()
async def learn_cmd(ctx, *, pokemon: str = None):
    if not await may_teach(ctx.author):
        raise commands.CheckFailure("Only the bot owner or a server manager can teach me.")
    await ctx.defer()
    await ctx.send(await bot.learn(ctx.channel.id, pokemon))


@bot.tree.command(name="dexscan", description="Dexscan tools — l = learn the latest spawn image")
async def dexscan_slash(interaction: discord.Interaction, action: Literal["l"], pokemon: str = None):
    if not interaction.guild or not await may_teach(interaction.user):
        return await interaction.response.send_message("⛔ Only the bot owner or a server manager can teach me.", ephemeral=True)
    await interaction.response.defer()
    await interaction.followup.send(await bot.learn(interaction.channel_id, pokemon))


@bot.hybrid_command(name="unlearn", description="Forget the learned copies of a Pokémon")
@commands.guild_only()
async def unlearn(ctx, *, pokemon: str):
    if not await may_teach(ctx.author):
        raise commands.CheckFailure("Only the bot owner or a server manager can do that.")
    n = resolve(pokemon)
    if not n:
        return await not_found(ctx, pokemon)
    removed = await asyncio.to_thread(bot.engine.remove_templates, n, LEARN_DIR)
    await ctx.send(f"🧹 Forgot {removed} learned copy/copies of **{n}**." if removed else f"**{n}** has nothing learned.")


@bot.event
async def on_command_error(ctx, err):
    err = getattr(err, "original", err)
    if isinstance(err, commands.CommandNotFound):
        return
    if isinstance(err, (commands.CheckFailure, commands.NoPrivateMessage)):
        return await ctx.send(f"⛔ {err}" if str(err) else "⛔ You can't use that here.")
    if isinstance(err, commands.BadArgument):
        return await ctx.send(f"❌ {err}")
    if isinstance(err, commands.MissingRequiredArgument):
        return await ctx.send(f"Missing `{err.param.name}`. Try `{ctx.prefix}help`.")
    log.exception("command error", exc_info=err)
    await ctx.send("⚠️ Something went wrong — it's been logged.")


@bot.tree.error
async def on_app_error(interaction: discord.Interaction, err):
    err = getattr(err, "original", err)
    msg = f"⛔ {err}" if isinstance(err, (commands.CheckFailure, discord.app_commands.CheckFailure)) and str(err) \
        else "⚠️ Something went wrong — it's been logged."
    if not isinstance(err, (commands.CheckFailure, discord.app_commands.CheckFailure)):
        log.exception("slash command error", exc_info=err)
    try:
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)
    except discord.HTTPException:
        pass


if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("Missing DISCORD_TOKEN (or TOKEN / BOT_TOKEN) in your .env")
    bot.run(TOKEN, log_handler=None)
