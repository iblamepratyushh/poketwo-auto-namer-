"""sources.py - pulls the whole Pokédex + sprites from PokéAPI / GitHub at startup (nothing stored by you
except a small JSON metadata cache, so restarts are quick). Override sprites with SPRITE_URL_TEMPLATE
(use {id} and/or {name}) in .env if you host your own."""
import asyncio, json, os, re

API = "https://pokeapi.co/api/v2"
SPRITE_TEMPLATE = os.getenv("SPRITE_URL_TEMPLATE") or \
    "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/{id}.png"
CACHE = os.getenv("META_CACHE", "pokedata_cache.json")
SKIP = re.compile(r"-(cap|cosplay|rock-star|belle|pop-star|phd|libre|totem|starter|original|world|partner|"
                  r"battle-bond|eternamax|busted|own-tempo|dusk|dawn|noice|hangry|zen-galar)", re.I)
PREFIX = {"alola": "Alolan", "galar": "Galarian", "hisui": "Hisuian", "paldea": "Paldean"}


def _en(names: list, lang: str) -> str:
    return next((n["name"] for n in names if n["language"]["name"] == lang), "")


def display_name(slug: str, species_en: str) -> str:
    """'vulpix-alola' -> 'Alolan Vulpix', 'charizard-mega-x' -> 'Mega Charizard X', 'x-gmax' -> 'Gigantamax X'."""
    parts = slug.split("-")
    base_slug = species_en.lower().replace(" ", "-").replace(".", "").replace("'", "").replace(":", "")
    if slug == base_slug or slug.replace("-", "") == base_slug.replace("-", ""):
        return species_en
    suffix = [p for p in slug.replace(base_slug, "", 1).strip("-").split("-") if p]
    if not suffix:
        return species_en
    if suffix[0] in PREFIX:
        return f"{PREFIX[suffix[0]]} {species_en}" + (" " + " ".join(s.title() for s in suffix[1:]) if suffix[1:] else "")
    if suffix[0] == "mega":
        return f"Mega {species_en}" + (" " + " ".join(s.upper() for s in suffix[1:]) if suffix[1:] else "")
    if suffix[0] == "gmax":
        return f"Gigantamax {species_en}"
    if suffix[0] == "primal":
        return f"Primal {species_en}"
    return " ".join(s.title() for s in suffix) + f" {species_en}"


def _id(url: str) -> int:
    return int(url.rstrip("/").rsplit("/", 1)[1])


async def _get_json(session, url, tries=4):
    for i in range(tries):
        try:
            async with session.get(url) as r:
                if r.status == 200:
                    return await r.json()
                if r.status == 404:
                    return None
        except Exception:
            pass
        await asyncio.sleep(0.5 * (i + 1))
    return None


async def load_entries(session) -> list:
    """Returns [{name, id, slug, gen, types, legendary, mythical, names{de,fr,ja,romaji}}]."""
    if os.path.exists(CACHE):
        with open(CACHE, encoding="utf-8") as f:
            data = json.load(f)
        if data:
            print(f"[sources] {len(data)} pokémon from cache ({CACHE})")
            return data
    lst = await _get_json(session, f"{API}/pokemon?limit=100000")
    if not lst:
        raise RuntimeError("Could not reach PokéAPI. Check your internet connection and try again.")
    mons = [(r["name"], _id(r["url"])) for r in lst["results"] if not SKIP.search(r["name"])]
    sem = asyncio.Semaphore(20)
    species_cache: dict = {}

    async def one(slug, pid):
        async with sem:
            p = await _get_json(session, f"{API}/pokemon/{pid}")
            if not p:
                return None
            sid = _id(p["species"]["url"])
            if sid not in species_cache:
                species_cache[sid] = asyncio.ensure_future(_get_json(session, f"{API}/pokemon-species/{sid}"))
        sp = await species_cache[sid]
        if not sp:
            return None
        en = _en(sp["names"], "en") or sp["name"].title()
        return {"name": display_name(slug, en), "id": pid, "slug": slug,
                "gen": _id(sp["generation"]["url"]) if sp.get("generation") else 0,
                "types": [t["type"]["name"] for t in sorted(p["types"], key=lambda t: t["slot"])],
                "legendary": bool(sp["is_legendary"]), "mythical": bool(sp["is_mythical"]),
                "names": {"de": _en(sp["names"], "de"), "fr": _en(sp["names"], "fr"),
                          "ja": _en(sp["names"], "ja-Hrkt") or _en(sp["names"], "ja"),
                          "romaji": _en(sp["names"], "roomaji")}}

    res = await asyncio.gather(*(one(s, i) for s, i in mons))
    out, seen = [], set()
    for e in res:
        if e and e["name"] not in seen:
            seen.add(e["name"]); out.append(e)
    # PokéAPI's generation URL ids are already 1..9 = Kanto..Paldea
    with open(CACHE, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False)
    print(f"[sources] fetched {len(out)} pokémon from PokéAPI (cached to {CACHE})")
    return out


def sprite_url(e: dict) -> str:
    return SPRITE_TEMPLATE.format(id=e["id"], name=e["slug"])


async def fetch_sprites(session, entries: list) -> list:
    """Download every sprite into memory. Returns [(name, bytes)]; entries with no sprite are dropped."""
    sem = asyncio.Semaphore(32)

    async def one(e):
        async with sem:
            for i in range(3):
                try:
                    async with session.get(sprite_url(e)) as r:
                        if r.status == 200:
                            return e["name"], await r.read()
                        if r.status == 404:
                            return None
                except Exception:
                    await asyncio.sleep(0.5 * (i + 1))
        return None

    out = [x for x in await asyncio.gather(*(one(e) for e in entries)) if x]
    print(f"[sources] {len(out)}/{len(entries)} sprites downloaded")
    return out


# ------------------------------------------------ sprites from your GitHub repo ---
import io, zipfile
from urllib.parse import quote

from core import norm

REPO = os.getenv("SPRITE_REPO", "iblamepratyushh/pokemon_images_cropped")
BRANCH = os.getenv("SPRITE_BRANCH", "main")
GH_TOKEN = os.getenv("GITHUB_TOKEN")                      # only needed if the repo is private
SOURCE = os.getenv("SPRITE_SOURCE", "pokeapi").lower()    # pokeapi (default) | auto | repo
IMG_EXT = (".png", ".webp", ".jpg", ".jpeg")
MIN_SIDE = 64                                              # repo sprites smaller than this are useless for matching


def extract_images(blob: bytes, depth: int = 0) -> list:
    """[(path, bytes)] for every image in a zip; a .zip inside the zip is opened too (paths get 'nested:')."""
    out = []
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        for info in z.infolist():
            n = info.filename
            base = os.path.basename(n)
            if info.is_dir() or "__MACOSX" in n or base.startswith("."):
                continue
            low = n.lower()
            if low.endswith(IMG_EXT):
                out.append((n, z.read(info)))
            elif low.endswith(".zip") and depth < 2:
                try:
                    out += [("nested:" + p, d) for p, d in extract_images(z.read(info), depth + 1)]
                except zipfile.BadZipFile:
                    pass
    return out


def map_to_entries(files: list, entries: list) -> tuple:
    """Match repo files to PokéAPI entries by file name (name, slug or dex number).
    Unmatched files are still used for naming (just without type/region data)."""
    by_id = {e["id"]: e for e in entries}
    by_name = {}
    for e in entries:
        by_name.setdefault(norm(e["name"]), e)
        by_name.setdefault(norm(e["slug"]), e)
    out, sprites, seen = [], [], set()
    for path, data in sorted(files):
        stem = os.path.splitext(os.path.basename(path))[0]
        e = by_id.get(int(stem)) if stem.isdigit() else by_name.get(norm(stem))
        if e:
            meta = dict(e)
        else:
            nice = re.sub(r"[_\-]+", " ", stem).strip().title() or stem
            meta = {"name": nice, "id": 0, "slug": norm(stem).replace(" ", "-"), "gen": 0, "types": [],
                    "legendary": False, "mythical": False, "names": {}}
        if meta["name"] in seen:
            continue
        seen.add(meta["name"])
        rel = path.split("/", 1)[1] if "/" in path else path           # drop the 'repo-branch/' prefix
        meta["thumb"] = None if path.startswith("nested:") else \
            f"https://raw.githubusercontent.com/{REPO}/{BRANCH}/{quote(rel)}"
        out.append(meta)
        sprites.append((meta["name"], data))
    return out, sprites


def sprites_look_usable(files: list) -> bool:
    from PIL import Image
    sides = []
    for _, data in files[:: max(1, len(files) // 15)][:15]:
        try:
            sides.append(max(Image.open(io.BytesIO(data)).size))
        except Exception:
            pass
    return bool(sides) and sorted(sides)[len(sides) // 2] >= MIN_SIDE


async def fetch_repo_files(session) -> list:
    """One request: GitHub serves the whole repo as a zip. Works for any file layout / nested zips."""
    import aiohttp
    url = (f"https://api.github.com/repos/{REPO}/zipball/{BRANCH}" if GH_TOKEN
           else f"https://codeload.github.com/{REPO}/zip/refs/heads/{BRANCH}")
    hdr = {"Authorization": f"Bearer {GH_TOKEN}"} if GH_TOKEN else {}
    async with session.get(url, headers=hdr, timeout=aiohttp.ClientTimeout(total=900)) as r:
        if r.status == 404:
            raise RuntimeError(f"repo {REPO} (branch {BRANCH}) not found - is the push finished and the repo public?")
        if r.status != 200:
            raise RuntimeError(f"GitHub answered HTTP {r.status}")
        blob = await r.read()
    files = await asyncio.to_thread(extract_images, blob)
    if not files:
        raise RuntimeError(f"no images found inside {REPO}")
    return files


async def load_all(session) -> tuple:
    """-> (entries, sprites). Your repo first; PokéAPI artwork if the repo is unreachable/empty/too small."""
    entries = await load_entries(session)
    if SOURCE in ("auto", "repo"):
        try:
            files = await fetch_repo_files(session)
            if sprites_look_usable(files):
                ents, sprites = await asyncio.to_thread(map_to_entries, files, entries)
                print(f"[sources] {len(sprites)} sprites loaded from github.com/{REPO}")
                return ents, sprites
            print(f"[sources] sprites in {REPO} are under {MIN_SIDE}px (8x8 is far too small to tell Pokémon apart) "
                  f"- re-upload them at 128-256px. Using PokéAPI artwork meanwhile.")
        except Exception as e:
            if SOURCE == "repo":
                raise
            print(f"[sources] repo sprites unavailable ({e}); using PokéAPI artwork")
    return entries, await fetch_sprites(session, entries)
