"""db.py - SQLite storage (stdlib only). All methods are synchronous and fast (WAL mode)."""
import json
import sqlite3
import threading
import time
from typing import Iterable, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS guild_cfg(guild_id INTEGER PRIMARY KEY, prefix TEXT, rare_role INTEGER,
    paradox_role INTEGER, regional_role INTEGER, manager_role INTEGER, collection_limit INTEGER);
CREATE TABLE IF NOT EXISTS guild_flags(guild_id INTEGER, flag TEXT, value INTEGER, PRIMARY KEY(guild_id, flag));
CREATE TABLE IF NOT EXISTS channel_flags(channel_id INTEGER, flag TEXT, value INTEGER, PRIMARY KEY(channel_id, flag));
CREATE TABLE IF NOT EXISTS channel_vals(channel_id INTEGER, key TEXT, value TEXT, PRIMARY KEY(channel_id, key));
CREATE TABLE IF NOT EXISTS hunts(guild_id INTEGER, user_id INTEGER, pokemon TEXT, PRIMARY KEY(guild_id, user_id));
CREATE TABLE IF NOT EXISTS global_hunt(user_id INTEGER PRIMARY KEY, pokemon TEXT);
CREATE TABLE IF NOT EXISTS global_off(user_id INTEGER, guild_id INTEGER, PRIMARY KEY(user_id, guild_id));
CREATE TABLE IF NOT EXISTS collection(guild_id INTEGER, user_id INTEGER, pokemon TEXT, PRIMARY KEY(guild_id, user_id, pokemon));
CREATE TABLE IF NOT EXISTS coll_role_limit(guild_id INTEGER, role_id INTEGER, lim INTEGER, PRIMARY KEY(guild_id, role_id));
CREATE TABLE IF NOT EXISTS quest(guild_id INTEGER, user_id INTEGER, kind TEXT, value TEXT, PRIMARY KEY(guild_id, user_id, kind, value));
CREATE TABLE IF NOT EXISTS afk(user_id INTEGER PRIMARY KEY);
CREATE TABLE IF NOT EXISTS warnings(case_id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER, user_id INTEGER,
    kind TEXT, pokemon TEXT, channel_id INTEGER, ts REAL);
CREATE TABLE IF NOT EXISTS timeouts(guild_id INTEGER, level INTEGER, minutes INTEGER, PRIMARY KEY(guild_id, level));
CREATE TABLE IF NOT EXISTS autolock(channel_id INTEGER PRIMARY KEY, guild_id INTEGER);
CREATE TABLE IF NOT EXISTS autolock_cfg(guild_id INTEGER PRIMARY KEY, delay INTEGER, duration INTEGER, triggers TEXT);
CREATE TABLE IF NOT EXISTS locks(channel_id INTEGER PRIMARY KEY, guild_id INTEGER, unlock_at REAL, prev TEXT);
CREATE TABLE IF NOT EXISTS starboard(channel_id INTEGER PRIMARY KEY, guild_id INTEGER, target_id INTEGER);
CREATE TABLE IF NOT EXISTS starboard_route(guild_id INTEGER, category TEXT, target_id INTEGER, PRIMARY KEY(guild_id, category));
CREATE TABLE IF NOT EXISTS starboard_cat(guild_id INTEGER, category TEXT, enabled INTEGER, PRIMARY KEY(guild_id, category));
CREATE TABLE IF NOT EXISTS stats(key TEXT PRIMARY KEY, value INTEGER);
"""

CHANNEL_FLAG_DEFAULTS = {"spawns": 1, "sh": 1, "collection": 1, "questping": 1, "rareping": 1, "paradoxping": 1,
                         "regionalping": 1, "catchcommand": 0, "shtimer": 0, "cltimer": 0, "manualsh": 0}
GUILD_FLAG_DEFAULTS = {"alts": 0, "hint": 0, "rarecollect": 1, "manualstarboard": 0, "shstealwarn": 0,
                       "clstealwarn": 0, "textnaming": 0, "showafk": 0}
STARBOARD_CATEGORIES = ["shiny", "gigantamax", "rare", "regional", "high_iv", "low_iv"]   # priority order


class Database:
    def __init__(self, path: str = "dexscan.db"):
        self.con = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.con.row_factory = sqlite3.Row
        self.lock = threading.RLock()
        with self.lock:
            self.con.execute("PRAGMA journal_mode=WAL")
            self.con.execute("PRAGMA synchronous=NORMAL")
            self.con.executescript(SCHEMA)

    # -- primitives
    def q(self, sql: str, args: Iterable = ()) -> list:
        with self.lock:
            return self.con.execute(sql, tuple(args)).fetchall()

    def one(self, sql: str, args: Iterable = ()):
        r = self.q(sql, args)
        return r[0] if r else None

    def x(self, sql: str, args: Iterable = ()) -> int:
        with self.lock:
            return self.con.execute(sql, tuple(args)).rowcount

    def ping(self) -> float:
        t = time.perf_counter()
        self.q("SELECT 1")
        return (time.perf_counter() - t) * 1000

    # -- guild config
    def get_prefix(self, gid: int, default: str = "-") -> str:
        r = self.one("SELECT prefix FROM guild_cfg WHERE guild_id=?", (gid,))
        return r["prefix"] if r and r["prefix"] else default

    def set_cfg(self, gid: int, **kw) -> None:
        allowed = {"prefix", "rare_role", "paradox_role", "regional_role", "manager_role", "collection_limit"}
        for k, v in kw.items():
            if k not in allowed:
                raise ValueError(k)
            self.x("INSERT OR IGNORE INTO guild_cfg(guild_id) VALUES(?)", (gid,))
            self.x(f"UPDATE guild_cfg SET {k}=? WHERE guild_id=?", (v, gid))

    def cfg(self, gid: int) -> dict:
        r = self.one("SELECT * FROM guild_cfg WHERE guild_id=?", (gid,))
        return dict(r) if r else {}

    # -- flags
    def gflag(self, gid: int, flag: str) -> bool:
        r = self.one("SELECT value FROM guild_flags WHERE guild_id=? AND flag=?", (gid, flag))
        return bool(r["value"]) if r else bool(GUILD_FLAG_DEFAULTS[flag])

    def set_gflag(self, gid: int, flag: str, v: bool) -> None:
        self.x("INSERT INTO guild_flags VALUES(?,?,?) ON CONFLICT(guild_id,flag) DO UPDATE SET value=excluded.value",
               (gid, flag, int(v)))

    def cflag(self, cid: int, flag: str) -> bool:
        r = self.one("SELECT value FROM channel_flags WHERE channel_id=? AND flag=?", (cid, flag))
        return bool(r["value"]) if r else bool(CHANNEL_FLAG_DEFAULTS[flag])

    def set_cflag(self, cid: int, flag: str, v: bool) -> None:
        self.x("INSERT INTO channel_flags VALUES(?,?,?) ON CONFLICT(channel_id,flag) DO UPDATE SET value=excluded.value",
               (cid, flag, int(v)))

    def cval(self, cid: int, key: str, default=None):
        r = self.one("SELECT value FROM channel_vals WHERE channel_id=? AND key=?", (cid, key))
        return r["value"] if r else default

    def set_cval(self, cid: int, key: str, v) -> None:
        if v is None:
            self.x("DELETE FROM channel_vals WHERE channel_id=? AND key=?", (cid, key))
        else:
            self.x("INSERT INTO channel_vals VALUES(?,?,?) ON CONFLICT(channel_id,key) DO UPDATE SET value=excluded.value",
                   (cid, key, str(v)))

    # -- shiny hunts
    def set_hunt(self, gid, uid, mon):
        self.x("INSERT INTO hunts VALUES(?,?,?) ON CONFLICT(guild_id,user_id) DO UPDATE SET pokemon=excluded.pokemon",
               (gid, uid, mon))

    def remove_hunt(self, gid, uid, mon) -> bool:
        return self.x("DELETE FROM hunts WHERE guild_id=? AND user_id=? AND pokemon=?", (gid, uid, mon)) > 0

    def get_hunt(self, gid, uid) -> Optional[str]:
        r = self.one("SELECT pokemon FROM hunts WHERE guild_id=? AND user_id=?", (gid, uid))
        return r["pokemon"] if r else None

    def set_global_hunt(self, uid, mon):
        self.x("INSERT INTO global_hunt VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET pokemon=excluded.pokemon", (uid, mon))

    def clear_global_hunt(self, uid) -> bool:
        return self.x("DELETE FROM global_hunt WHERE user_id=?", (uid,)) > 0

    def get_global_hunt(self, uid) -> Optional[str]:
        r = self.one("SELECT pokemon FROM global_hunt WHERE user_id=?", (uid,))
        return r["pokemon"] if r else None

    def toggle_global_off(self, uid, gid) -> bool:
        """Returns True if the user's global lists are now DISABLED in this server."""
        if self.one("SELECT 1 FROM global_off WHERE user_id=? AND guild_id=?", (uid, gid)):
            self.x("DELETE FROM global_off WHERE user_id=? AND guild_id=?", (uid, gid))
            return False
        self.x("INSERT INTO global_off VALUES(?,?)", (uid, gid))
        return True

    def is_global_off(self, uid, gid) -> bool:
        return self.one("SELECT 1 FROM global_off WHERE user_id=? AND guild_id=?", (uid, gid)) is not None

    # -- collection (guild_id 0 == global list)
    def coll_add(self, gid, uid, mon) -> bool:
        return self.x("INSERT OR IGNORE INTO collection VALUES(?,?,?)", (gid, uid, mon)) > 0

    def coll_remove(self, gid, uid, mon) -> bool:
        return self.x("DELETE FROM collection WHERE guild_id=? AND user_id=? AND pokemon=?", (gid, uid, mon)) > 0

    def coll_list(self, gid, uid) -> list:
        return [r["pokemon"] for r in self.q(
            "SELECT pokemon FROM collection WHERE guild_id=? AND user_id=? ORDER BY rowid", (gid, uid))]

    def coll_clear(self, gid, uid) -> int:
        return self.x("DELETE FROM collection WHERE guild_id=? AND user_id=?", (gid, uid))

    def coll_trim(self, gid: int, uid: int, limit: int) -> int:
        lst = self.coll_list(gid, uid)
        for m in lst[limit:]:
            self.coll_remove(gid, uid, m)
        return max(0, len(lst) - limit)

    def role_limits(self, gid) -> dict:
        return {r["role_id"]: r["lim"] for r in self.q("SELECT role_id, lim FROM coll_role_limit WHERE guild_id=?", (gid,))}

    def set_role_limit(self, gid, rid, lim):
        self.x("INSERT INTO coll_role_limit VALUES(?,?,?) ON CONFLICT(guild_id,role_id) DO UPDATE SET lim=excluded.lim",
               (gid, rid, lim))

    def del_role_limit(self, gid, rid) -> bool:
        return self.x("DELETE FROM coll_role_limit WHERE guild_id=? AND role_id=?", (gid, rid)) > 0

    # -- quest pings
    def quest_get(self, gid, uid) -> dict:
        out: dict = {}
        for r in self.q("SELECT kind, value FROM quest WHERE guild_id=? AND user_id=?", (gid, uid)):
            out.setdefault(r["kind"], set()).add(r["value"])
        return out

    def quest_set(self, gid, uid, kind, values) -> None:
        self.x("DELETE FROM quest WHERE guild_id=? AND user_id=? AND kind=?", (gid, uid, kind))
        for v in values:
            self.x("INSERT OR IGNORE INTO quest VALUES(?,?,?,?)", (gid, uid, kind, v))

    def quest_users(self, gid, kind, value) -> list:
        return [r["user_id"] for r in self.q(
            "SELECT user_id FROM quest WHERE guild_id=? AND kind=? AND value=?", (gid, kind, value))]

    # -- afk
    def toggle_afk(self, uid) -> bool:
        if self.one("SELECT 1 FROM afk WHERE user_id=?", (uid,)):
            self.x("DELETE FROM afk WHERE user_id=?", (uid,)); return False
        self.x("INSERT INTO afk VALUES(?)", (uid,)); return True

    def is_afk(self, uid) -> bool:
        return self.one("SELECT 1 FROM afk WHERE user_id=?", (uid,)) is not None

    # -- warnings / timeouts
    def add_warning(self, gid, uid, kind, mon, cid) -> tuple:
        with self.lock:
            self.x("INSERT INTO warnings(guild_id,user_id,kind,pokemon,channel_id,ts) VALUES(?,?,?,?,?,?)",
                   (gid, uid, kind, mon, cid, time.time()))
            case = self.one("SELECT last_insert_rowid() AS i")["i"]
            n = self.one("SELECT COUNT(*) AS n FROM warnings WHERE guild_id=? AND user_id=?", (gid, uid))["n"]
        return case, n

    def warnings(self, gid, uid) -> list:
        return self.q("SELECT * FROM warnings WHERE guild_id=? AND user_id=? ORDER BY case_id", (gid, uid))

    def del_warning(self, gid, case_id) -> bool:
        return self.x("DELETE FROM warnings WHERE guild_id=? AND case_id=?", (gid, case_id)) > 0

    def set_timeout_level(self, gid, level, minutes):
        self.x("INSERT INTO timeouts VALUES(?,?,?) ON CONFLICT(guild_id,level) DO UPDATE SET minutes=excluded.minutes",
               (gid, level, minutes))

    def unset_timeout_level(self, gid, level) -> bool:
        return self.x("DELETE FROM timeouts WHERE guild_id=? AND level=?", (gid, level)) > 0

    def timeouts(self, gid) -> dict:
        return {r["level"]: r["minutes"] for r in self.q(
            "SELECT level, minutes FROM timeouts WHERE guild_id=? ORDER BY level", (gid,))}

    # -- auto-lock
    def lock_cfg(self, gid) -> dict:
        r = self.one("SELECT * FROM autolock_cfg WHERE guild_id=?", (gid,))
        if not r:
            return {"delay": 0, "duration": 3600, "triggers": ["sh", "collection"]}
        return {"delay": r["delay"], "duration": r["duration"], "triggers": [t for t in r["triggers"].split(",") if t]}

    def set_lock_cfg(self, gid, **kw):
        cur = self.lock_cfg(gid); cur.update(kw)
        self.x("INSERT INTO autolock_cfg VALUES(?,?,?,?) ON CONFLICT(guild_id) DO UPDATE SET delay=excluded.delay,"
               " duration=excluded.duration, triggers=excluded.triggers",
               (gid, cur["delay"], cur["duration"], ",".join(cur["triggers"])))

    def lock_channels(self, gid) -> list:
        return [r["channel_id"] for r in self.q("SELECT channel_id FROM autolock WHERE guild_id=?", (gid,))]

    def lock_enroll(self, gid, cid): self.x("INSERT OR IGNORE INTO autolock VALUES(?,?)", (cid, gid))
    def lock_unenroll(self, cid): return self.x("DELETE FROM autolock WHERE channel_id=?", (cid,)) > 0
    def lock_replace(self, gid, cids):
        self.x("DELETE FROM autolock WHERE guild_id=?", (gid,))
        for c in cids: self.lock_enroll(gid, c)
    def is_enrolled(self, cid) -> bool: return self.one("SELECT 1 FROM autolock WHERE channel_id=?", (cid,)) is not None

    def save_lock(self, cid, gid, unlock_at, prev: dict):
        self.x("INSERT INTO locks VALUES(?,?,?,?) ON CONFLICT(channel_id) DO UPDATE SET unlock_at=excluded.unlock_at,"
               " prev=excluded.prev", (cid, gid, unlock_at, json.dumps(prev)))

    def get_lock(self, cid):
        r = self.one("SELECT * FROM locks WHERE channel_id=?", (cid,))
        return (r["guild_id"], r["unlock_at"], {int(k): v for k, v in json.loads(r["prev"]).items()}) if r else None

    def del_lock(self, cid): self.x("DELETE FROM locks WHERE channel_id=?", (cid,))
    def all_locks(self) -> list: return [dict(r) for r in self.q("SELECT * FROM locks")]

    # -- starboard
    def set_starboard(self, cid, gid, target): 
        self.x("INSERT INTO starboard VALUES(?,?,?) ON CONFLICT(channel_id) DO UPDATE SET target_id=excluded.target_id", (cid, gid, target))
    def del_starboard(self, cid) -> bool: return self.x("DELETE FROM starboard WHERE channel_id=?", (cid,)) > 0
    def starboard_for(self, cid) -> Optional[int]:
        r = self.one("SELECT target_id FROM starboard WHERE channel_id=?", (cid,)); return r["target_id"] if r else None
    def starboards(self, gid) -> list: return [(r["channel_id"], r["target_id"]) for r in self.q("SELECT channel_id, target_id FROM starboard WHERE guild_id=?", (gid,))]
    def set_route(self, gid, cat, target):
        if target is None: self.x("DELETE FROM starboard_route WHERE guild_id=? AND category=?", (gid, cat))
        else: self.x("INSERT INTO starboard_route VALUES(?,?,?) ON CONFLICT(guild_id,category) DO UPDATE SET target_id=excluded.target_id", (gid, cat, target))
    def routes(self, gid) -> dict: return {r["category"]: r["target_id"] for r in self.q("SELECT category, target_id FROM starboard_route WHERE guild_id=?", (gid,))}
    def cat_enabled(self, gid, cat) -> bool:
        r = self.one("SELECT enabled FROM starboard_cat WHERE guild_id=? AND category=?", (gid, cat)); return bool(r["enabled"]) if r else True
    def set_cat_enabled(self, gid, cat, v):
        self.x("INSERT INTO starboard_cat VALUES(?,?,?) ON CONFLICT(guild_id,category) DO UPDATE SET enabled=excluded.enabled", (gid, cat, int(v)))

    # -- cleanup helpers
    def user_ids_in_guild_lists(self, gid) -> set:
        ids = set()
        for sql in ("SELECT user_id FROM hunts WHERE guild_id=?", "SELECT user_id FROM collection WHERE guild_id=?",
                    "SELECT user_id FROM quest WHERE guild_id=?"):
            ids |= {r["user_id"] for r in self.q(sql, (gid,))}
        return ids

    def remove_user_tags(self, gid, uid) -> int:
        n = 0
        for sql in ("DELETE FROM hunts WHERE guild_id=? AND user_id=?", "DELETE FROM collection WHERE guild_id=? AND user_id=?",
                    "DELETE FROM quest WHERE guild_id=? AND user_id=?"):
            n += self.x(sql, (gid, uid))
        return n

    # -- stats
    def bump(self, key: str, n: int = 1):
        self.x("INSERT INTO stats VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=value+?", (key, n, n))

    def stat(self, key: str) -> int:
        r = self.one("SELECT value FROM stats WHERE key=?", (key,)); return r["value"] if r else 0
