"""
dexscan_engine.py - sprite matching engine (numpy + Pillow only).

Pipeline for a spawn image:
  1. isolate()  : find the Pokemon inside the spawn scene (border-colour background
                  removal -> bounding box). Falls back to centre crop.
  2. fingerprint: DCT pHash (8x8 -> 64 bit), dHash (64 bit), 4x4x4 colour histogram.
  3. match()    : weighted distance against every sprite. Returns None unless the best
                  match is both close enough AND clearly ahead of the runner-up, so the
                  bot stays silent instead of naming the wrong Pokemon.
"""
from __future__ import annotations

import hashlib
import io
import os
import re
import threading
from urllib.parse import quote, unquote
from dataclasses import dataclass
from typing import Optional

import numpy as np
from PIL import Image

try:
    from cv_bank import FeatureBank, cutout
except Exception:          # OpenCV missing -> hash-only mode
    FeatureBank = cutout = None

HASH_SIZE = 8            # 8x8 -> 64-bit hashes
WORK = 32                # resize target before DCT (DCT of 32x32, keep top-left 8x8)
CANVAS = 128             # normalised canvas for isolated Pokemon


def _dct_matrix(n: int) -> np.ndarray:
    k = np.arange(n)[:, None]
    i = np.arange(n)[None, :]
    m = np.cos(np.pi * (2 * i + 1) * k / (2 * n)) * np.sqrt(2.0 / n)
    m[0, :] = np.sqrt(1.0 / n)
    return m


_DCT = _dct_matrix(WORK)


def _to_rgb_on_white(img: Image.Image) -> Image.Image:
    """Flatten transparency onto a neutral grey so sprites and spawns compare fairly."""
    img = img.convert("RGBA")
    bg = Image.new("RGBA", img.size, (127, 127, 127, 255))
    bg.alpha_composite(img)
    return bg.convert("RGB")


def _square_pad(img: Image.Image, size: int = CANVAS) -> Image.Image:
    """Resize keeping aspect ratio, centre on a grey square canvas."""
    w, h = img.size
    scale = size / max(w, h)
    nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
    img = img.resize((nw, nh), Image.LANCZOS)
    canvas = Image.new("RGB", (size, size), (127, 127, 127))
    canvas.paste(img, ((size - nw) // 2, (size - nh) // 2))
    return canvas


def phash(img: Image.Image) -> np.ndarray:
    g = np.asarray(img.convert("L").resize((WORK, WORK), Image.LANCZOS), dtype=np.float64)
    d = _DCT @ g @ _DCT.T
    low = d[:HASH_SIZE, :HASH_SIZE].flatten()
    med = np.median(low[1:])          # ignore the DC term
    return low > med


def dhash(img: Image.Image) -> np.ndarray:
    g = np.asarray(img.convert("L").resize((HASH_SIZE + 1, HASH_SIZE), Image.LANCZOS), dtype=np.float64)
    return (g[:, 1:] > g[:, :-1]).flatten()


def colour_hist(img: Image.Image, mask: Optional[np.ndarray] = None) -> np.ndarray:
    a = np.asarray(img.convert("RGB").resize((64, 64), Image.BILINEAR), dtype=np.int32) // 64
    idx = a[..., 0] * 16 + a[..., 1] * 4 + a[..., 2]
    if mask is not None:
        idx = idx[mask]
    h = np.bincount(idx.flatten(), minlength=64).astype(np.float64)
    s = h.sum()
    return h / s if s else h


@dataclass
class Fingerprint:
    p: np.ndarray
    d: np.ndarray
    c: np.ndarray


def fingerprint(img: Image.Image, mask: Optional[np.ndarray] = None) -> Fingerprint:
    sq = _square_pad(img)
    cmask = None
    if mask is not None:
        m = Image.fromarray((mask * 255).astype("uint8"))
        cmask = np.asarray(_square_pad_mask(m).resize((64, 64), Image.NEAREST)) > 127
    return Fingerprint(phash(sq), dhash(sq), colour_hist(sq, cmask))


def _square_pad_mask(m: Image.Image, size: int = CANVAS) -> Image.Image:
    w, h = m.size
    scale = size / max(w, h)
    nw, nh = max(1, round(w * scale)), max(1, round(h * scale))
    m = m.resize((nw, nh), Image.NEAREST)
    canvas = Image.new("L", (size, size), 0)
    canvas.paste(m, ((size - nw) // 2, (size - nh) // 2))
    return canvas


def _hamming(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return (a != b).sum(axis=-1)


# ---------------------------------------------------------------- isolation ---
GREY = 127


def _clean_mask(mask: np.ndarray) -> np.ndarray:
    """Remove speckle (opening) with Pillow filters - no OpenCV needed."""
    from PIL import ImageFilter
    m = Image.fromarray((mask * 255).astype("uint8"))
    m = m.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.MaxFilter(3))
    return np.asarray(m) > 127


def _masked_crop(arr: np.ndarray, mask: np.ndarray) -> Optional[tuple]:
    """Crop to the mask bounding box, grey-fill everything outside the mask."""
    h, w = mask.shape
    mask = _clean_mask(mask)
    rows = np.where(mask.sum(axis=1) > max(2, w * 0.01))[0]
    cols = np.where(mask.sum(axis=0) > max(2, h * 0.01))[0]
    if not rows.size or not cols.size:
        return None
    y0, y1, x0, x1 = rows[0], rows[-1] + 1, cols[0], cols[-1] + 1
    area = (y1 - y0) * (x1 - x0)
    if not (0.02 * h * w < area < 0.95 * h * w):
        return None
    sub, msub = arr[y0:y1, x0:x1], mask[y0:y1, x0:x1]
    out = np.where(msub[..., None], sub, GREY).astype("uint8")
    return Image.fromarray(out), msub


def isolate(img: Image.Image) -> list:
    """Candidate (image, mask) pairs of the Pokemon, best guess first.

    1. border-median background removal      (flat backgrounds)
    2. top/bottom-row column reference       (horizontal gradients / skies)
    3. central crop, 4. whole image          (last-resort fallbacks, no mask)
    """
    rgb = _to_rgb_on_white(img)
    arr = np.asarray(rgb, dtype=np.int32)
    h, w, _ = arr.shape
    out: list = []

    border = np.concatenate([arr[0], arr[-1], arr[:, 0], arr[:, -1]])
    bg = np.median(border, axis=0)
    r = _masked_crop(arr, np.abs(arr - bg).sum(axis=2) > 60)
    if r:
        out.append(r)

    k = max(2, h // 20)
    ref = np.median(np.concatenate([arr[:k], arr[-k:]], axis=0), axis=0)      # (w, 3)
    r = _masked_crop(arr, np.abs(arr - ref[None, :, :]).sum(axis=2) > 60)
    if r:
        out.append(r)

    cx0, cy0 = int(w * 0.2), int(h * 0.2)
    out.append((rgb.crop((cx0, cy0, w - cx0, h - cy0)), None))
    out.append((rgb, None))
    return out


def _tight_alpha_crop(img: Image.Image) -> tuple:
    """For sprites: crop to alpha bbox, grey-fill transparent pixels, return (img, mask)."""
    rgba = img.convert("RGBA")
    a = np.asarray(rgba)[..., 3]
    mask = a > 16
    if mask.any():
        ys, xs = np.where(mask)
        rgba = rgba.crop((xs.min(), ys.min(), xs.max() + 1, ys.max() + 1))
        mask = mask[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    else:
        mask = np.ones((rgba.height, rgba.width), dtype=bool)
    return _to_rgb_on_white(rgba), mask


# ------------------------------------------------------------------ engine ---
@dataclass
class Match:
    name: str
    score: float
    margin: float
    confidence: float
    how: str = "hash"            # which stages agreed: hash, cv, cv-cut
    cands: tuple = ()


STRONG_HASH_SCORE, STRONG_HASH_MARGIN, STRONG_INLIERS = 0.12, 0.12, 30
MAX_LEARNED = 5                  # learned copies per Pokémon


class Dexscan:
    """Accuracy first: every stage runs; a name is only returned when the stages agree (or one is overwhelming).
    Anything doubtful stays silent - and `learn` fixes that Pokémon permanently."""
    W_P, W_D, W_C = 0.55, 0.25, 0.20
    MAX_SCORE, MIN_MARGIN = 0.25, 0.04

    def __init__(self):
        self.names: list = []
        self.P = self.D = self.C = self.row_uid = None
        self.base_n = 0
        self.bank = None
        self._lock = threading.RLock()

    def _finish_rows(self):
        ids = {n: i for i, n in enumerate(dict.fromkeys(self.names))}
        self.row_uid = np.array([ids[n] for n in self.names], dtype=np.int32)

    @classmethod
    def from_sprites(cls, items: list, cache_path: Optional[str] = None) -> "Dexscan":
        """items = [(name, image_bytes)]. cache_path (.npz) stores only tiny hash arrays, keyed on sprite content."""
        self = cls()
        cached = {}
        if cache_path and os.path.exists(cache_path):
            try:
                z = np.load(cache_path, allow_pickle=False)
                cached = {str(n): (str(h), p, d, c) for n, h, p, d, c in zip(z["n"], z["h"], z["p"], z["d"], z["c"])}
            except Exception:
                cached = {}
        names, P, D, C, H = [], [], [], [], []
        for name, data in items:
            h = hashlib.sha1(data).hexdigest()[:16]
            if name in cached and cached[name][0] == h:
                _, p, d, c = cached[name]
            else:
                try:
                    spr, smask = _tight_alpha_crop(Image.open(io.BytesIO(data)))
                    fp = fingerprint(spr, smask)
                except Exception as e:
                    print(f"[dexscan] skipped {name}: {e}"); continue
                p, d, c = fp.p, fp.d, fp.c
            names.append(name); P.append(p); D.append(d); C.append(c); H.append(h)
        if not names:
            raise RuntimeError("No sprites could be fingerprinted")
        self.names, self.P, self.D, self.C = names, np.stack(P), np.stack(D), np.stack(C)
        self.base_n = len(names)
        self._finish_rows()
        if FeatureBank is not None:
            try:
                self.bank = FeatureBank(); self.bank.add_sprites(list(items))
            except Exception as e:
                print(f"[dexscan] OpenCV stage disabled ({e}); hash-only"); self.bank = None
        if cache_path:
            np.savez_compressed(cache_path, n=np.array(names), h=np.array(H), p=self.P, d=self.D, c=self.C)
        print(f"[dexscan] ready with {len(names)} pokémon")
        return self

    # ---------------------------------------------------------------- stages
    def _hash_stage(self, img: Image.Image, cut) -> tuple:
        with self._lock:
            P, D, C, uid, names = self.P, self.D, self.C, self.row_uid, self.names
        cands = isolate(img)
        if cut is not None:
            cands.insert(0, _tight_alpha_crop(cut))
        best = None
        for crop, cmask in cands:
            fp = fingerprint(crop, cmask)
            s = (self.W_P * (_hamming(P, fp.p) / 64.0) + self.W_D * (_hamming(D, fp.d) / 64.0)
                 + self.W_C * 0.5 * np.abs(C - fp.c).sum(axis=1))
            i = int(np.argmin(s)); top = float(s[i])
            other = s[uid != uid[i]]
            margin = (float(other.min()) if other.size else 1.0) - top
            if best is None or top < best.score:
                near = dict.fromkeys(names[j] for j in np.argsort(s)[:12])
                best = Match(names[i], top, margin, max(0.0, min(1.0, 1 - top / 0.5)), cands=tuple(list(near)[:5]))
        ok = best is not None and best.score <= self.MAX_SCORE and best.margin >= self.MIN_MARGIN
        return (best if ok else None), best

    def identify(self, data: bytes) -> Optional[Match]:
        try:
            img = Image.open(io.BytesIO(data)); img.load()
        except Exception:
            return None
        cut = cutout(img) if cutout is not None else None
        sure, best = self._hash_stage(img, cut)
        votes: dict = {}                                   # name -> [(stage, strong)]
        if sure:
            votes.setdefault(sure.name, []).append(
                ("hash", sure.score <= STRONG_HASH_SCORE and sure.margin >= STRONG_HASH_MARGIN))
        if self.bank is not None:
            extra = list(best.cands) if best else None
            r = self.bank.identify(img, extra)
            if r:
                votes.setdefault(r.name, []).append(("cv", r.inliers >= STRONG_INLIERS))
            if cut is not None:
                r = self.bank.identify(cut, extra, use_alpha=True, size=480)
                if r:
                    votes.setdefault(r.name, []).append(("cv-cut", r.inliers >= STRONG_INLIERS))
        if len(votes) != 1:                                # nothing, or the stages disagree -> stay silent
            return None
        name, st = next(iter(votes.items()))
        if len(st) < 2 and not any(strong for _, strong in st):
            return None                                    # one weak vote is not enough
        return Match(name, 0.0, 1.0, min(1.0, 0.5 + 0.25 * len(st)), how="+".join(s for s, _ in st))

    # ---------------------------------------------------------------- learning
    def learned_count(self, name: str) -> int:
        return sum(1 for n in self.names[self.base_n:] if n == name)

    def add_template(self, name: str, data: bytes, save_dir: Optional[str] = None, rebuild: bool = True) -> tuple:
        """Learn an exact copy of a spawn image as an extra reference for `name` (the original sprite is kept)."""
        if cutout is None:
            return False, "OpenCV isn't installed, so I can't cut the Pokémon out."
        if self.learned_count(name) >= MAX_LEARNED:
            return False, f"**{name}** already has {MAX_LEARNED} learned copies — use `unlearn {name}` first."
        try:
            img = Image.open(io.BytesIO(data)); img.load()
        except Exception:
            return False, "I couldn't read that image."
        cut = cutout(img)
        if cut is None:
            return False, "I couldn't cut the Pokémon cleanly out of the background, so I didn't save it."
        spr, smask = _tight_alpha_crop(cut)
        fp = fingerprint(spr, smask)
        buf = io.BytesIO(); cut.save(buf, "PNG")
        if self.bank is not None and not self.bank.add_template(name, buf.getvalue(), rebuild):
            return False, "That image has too few details for me to learn from."
        with self._lock:
            self.names = self.names + [name]
            self.P, self.D, self.C = np.vstack([self.P, fp.p[None]]), np.vstack([self.D, fp.d[None]]), np.vstack([self.C, fp.c[None]])
            self._finish_rows()
        if save_dir:
            os.makedirs(save_dir, exist_ok=True)
            with open(os.path.join(save_dir, f"{quote(name, safe='')}__{hashlib.sha1(data).hexdigest()[:10]}.png"), "wb") as f:
                f.write(data)                              # the exact image, byte for byte
        return True, f"learned (**{name}** now has {self.learned_count(name)} learned copy/copies)."

    def load_learned(self, save_dir: str) -> int:
        if not os.path.isdir(save_dir):
            return 0
        known, n = set(self.names[:self.base_n]), 0
        for f in sorted(os.listdir(save_dir)):
            name = unquote(f.split("__", 1)[0])
            if f.lower().endswith(".png") and name in known:
                with open(os.path.join(save_dir, f), "rb") as fh:
                    n += self.add_template(name, fh.read(), None, rebuild=False)[0]
        if self.bank is not None:
            self.bank.rebuild_learned()
        print(f"[dexscan] loaded {n} learned template(s)")
        return n

    def remove_templates(self, name: str, save_dir: Optional[str] = None) -> int:
        removed = self.learned_count(name)
        with self._lock:
            keep = [i for i in range(len(self.names)) if i < self.base_n or self.names[i] != name]
            self.names = [self.names[i] for i in keep]
            self.P, self.D, self.C = self.P[keep], self.D[keep], self.C[keep]
            self._finish_rows()
        if self.bank is not None:
            self.bank.drop_learned(name)
        if save_dir and os.path.isdir(save_dir):
            for f in os.listdir(save_dir):
                if f.startswith(quote(name, safe="") + "__"):
                    os.remove(os.path.join(save_dir, f))
        return removed
