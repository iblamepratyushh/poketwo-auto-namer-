"""cv_bank.py - OpenCV stage (free, CPU): GrabCut background removal, CLAHE detail enhancement, SIFT features,
FLANN voting over ALL sprites (+ learned copies), RANSAC geometric verification of the top candidates."""
from __future__ import annotations

import io
import os
import threading
from dataclasses import dataclass
from typing import Optional

import numpy as np
from PIL import Image

try:
    import cv2
except ImportError:          # bot still works (hash-only) without OpenCV
    cv2 = None

SPR, QRY, QRY_CUT, LEARN = 160, 400, 480, 224     # working sizes (long side)
RATIO = 0.78
MIN_INLIERS = int(os.getenv("CV_MIN_INLIERS", "9"))   # geometric inliers needed (lower = names more, risks wrong)
CLEAR_MARGIN = 0.6                                    # runner-up must have < 60% of winner's inliers (or < 5)


@dataclass
class CVMatch:
    name: str
    inliers: int
    runner_up: int


def _gray_and_mask(img: Image.Image, size: int, use_alpha: bool):
    img = img.convert("RGBA")
    s = size / max(img.size)
    img = img.resize((max(1, round(img.width * s)), max(1, round(img.height * s))), Image.LANCZOS)
    a = np.asarray(img)[..., 3]
    bg = Image.new("RGBA", img.size, (127, 127, 127, 255)); bg.alpha_composite(img)
    gray = cv2.cvtColor(np.asarray(bg.convert("RGB")), cv2.COLOR_RGB2GRAY)
    gray = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(4, 4)).apply(gray)          # bring out fine detail
    mask = cv2.erode((a > 200).astype("uint8") * 255, np.ones((5, 5), np.uint8)) if use_alpha else None
    return gray, mask


def _rootsift(d):
    if d is None or len(d) == 0:
        return None
    d = d / (np.abs(d).sum(axis=1, keepdims=True) + 1e-7)
    return np.sqrt(d).astype("float32")


def cutout(img: Image.Image) -> Optional[Image.Image]:
    """GrabCut the Pokémon out of its background -> tight RGBA crop, or None if it can't be done cleanly."""
    if cv2 is None:
        return None
    rgb = np.asarray(img.convert("RGB"))
    h, w = rgb.shape[:2]
    s = min(1.0, 320 / max(h, w))
    small = cv2.resize(rgb, (max(8, round(w * s)), max(8, round(h * s))), interpolation=cv2.INTER_AREA)
    sh, sw = small.shape[:2]
    m = np.full((sh, sw), cv2.GC_PR_BGD, np.uint8)
    m[int(sh * .08):int(sh * .92), int(sw * .12):int(sw * .88)] = cv2.GC_PR_FGD      # Pokémon is roughly central
    b = max(2, int(min(sh, sw) * .03))
    m[:b] = m[-b:] = cv2.GC_BGD; m[:, :b] = m[:, -b:] = cv2.GC_BGD                    # frame is surely background
    try:
        cv2.grabCut(small, m, None, np.zeros((1, 65)), np.zeros((1, 65)), 5, cv2.GC_INIT_WITH_MASK)
    except cv2.error:
        return None
    fg = ((m == cv2.GC_FGD) | (m == cv2.GC_PR_FGD)).astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(fg, connectivity=8)
    if n <= 1:
        return None
    fg = (lab == 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))).astype(np.uint8)
    if not (0.02 < fg.mean() < 0.85):
        return None
    fg = cv2.morphologyEx(fg, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    fg = cv2.resize(fg, (w, h), interpolation=cv2.INTER_NEAREST)
    ys, xs = np.where(fg > 0)
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    rgba = np.dstack([rgb, fg * 255]).astype("uint8")[y0:y1, x0:x1]
    return Image.fromarray(rgba, "RGBA")


class FeatureBank:
    def __init__(self):
        if cv2 is None:
            raise RuntimeError("opencv not installed")
        self.sprite_sift = cv2.SIFT_create(nfeatures=140, contrastThreshold=0.02)
        self.learn_sift = cv2.SIFT_create(nfeatures=260, contrastThreshold=0.015)
        self.query_sift = cv2.SIFT_create(nfeatures=900, contrastThreshold=0.015)
        self.names: list = []
        self.kps: list = []
        self.descs: list = []
        self.n_main = 0
        self.main = (None, None)         # (flann, owner row ids)
        self.learned = (None, None)
        self.lock = threading.RLock()

    # -- building
    def _append(self, name, gray, mask, sift) -> bool:
        kp, d = sift.detectAndCompute(gray, mask)
        d = _rootsift(d)
        if d is None or len(kp) < 6:
            return False
        self.names.append(name); self.kps.append(np.float32([k.pt for k in kp])); self.descs.append(d)
        return True

    def _build(self, start: int, stop: int):
        if stop - start < 1:
            return (None, None)
        descs = self.descs[start:stop]
        owner = np.concatenate([np.full(len(d), start + i, np.int32) for i, d in enumerate(descs)])
        f = cv2.FlannBasedMatcher(dict(algorithm=1, trees=4), dict(checks=64))
        f.add([np.vstack(descs)]); f.train()
        return (f, owner)

    def add_sprites(self, items: list) -> None:
        with self.lock:
            for name, data in items:
                try:
                    gray, mask = _gray_and_mask(Image.open(io.BytesIO(data)), SPR, True)
                    self._append(name, gray, mask, self.sprite_sift)
                except Exception:
                    continue
            self.n_main = len(self.names)
            self.main = self._build(0, self.n_main)
        print(f"[cv] indexed {self.n_main} sprites")

    def add_template(self, name: str, png: bytes, rebuild: bool = True) -> bool:
        gray, mask = _gray_and_mask(Image.open(io.BytesIO(png)), LEARN, True)
        with self.lock:
            ok = self._append(name, gray, mask, self.learn_sift)
            if ok and rebuild:
                self.rebuild_learned()
            return ok

    def rebuild_learned(self) -> None:
        with self.lock:
            self.learned = self._build(self.n_main, len(self.names))

    def drop_learned(self, name: str) -> None:
        with self.lock:
            keep = [i for i in range(len(self.names)) if i < self.n_main or self.names[i] != name]
            self.names = [self.names[i] for i in keep]
            self.kps = [self.kps[i] for i in keep]
            self.descs = [self.descs[i] for i in keep]
            self.rebuild_learned()

    # -- matching
    def _verify(self, row: int, qkp: np.ndarray, qdesc: np.ndarray) -> int:
        pairs = cv2.BFMatcher(cv2.NORM_L2).knnMatch(self.descs[row], qdesc, k=2)
        good = [p[0] for p in pairs if len(p) == 2 and p[0].distance < RATIO * p[1].distance]
        if len(good) < 4:
            return 0
        src = self.kps[row][[m.queryIdx for m in good]]
        dst = qkp[[m.trainIdx for m in good]]
        M, inl = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC, ransacReprojThreshold=4.0)
        if M is None or not (0.25 < float(np.hypot(M[0, 0], M[1, 0])) < 6.0):
            return 0
        return int(inl.sum())

    def identify(self, img: Image.Image, extra: Optional[list] = None, topk: int = 10,
                 use_alpha: bool = False, size: int = QRY) -> Optional[CVMatch]:
        gray, mask = _gray_and_mask(img, size, use_alpha)
        kp, d = self.query_sift.detectAndCompute(gray, mask)
        qdesc = _rootsift(d)
        if qdesc is None or len(kp) < 8:
            return None
        qkp = np.float32([k.pt for k in kp])
        with self.lock:
            votes = np.zeros(len(self.names), dtype=np.int32)
            for flann, owner in (self.main, self.learned):
                if flann is None or len(owner) < 2:
                    continue
                for p in flann.knnMatch(qdesc, k=2):
                    if len(p) == 2 and p[0].distance < 0.85 * p[1].distance:
                        votes[owner[p[0].trainIdx]] += 1
            cand = [int(i) for i in np.argsort(-votes)[:topk]]
            rows: dict = {}
            for i, n in enumerate(self.names):
                rows.setdefault(n, []).append(i)
            for n in extra or []:
                cand += [r for r in rows.get(n, []) if r not in cand]
            by_name: dict = {}
            for i in cand:
                by_name[self.names[i]] = max(by_name.get(self.names[i], 0), self._verify(i, qkp, qdesc))
        ranked = sorted(by_name.items(), key=lambda kv: -kv[1])
        if not ranked:
            return None
        best_name, best = ranked[0]
        second = ranked[1][1] if len(ranked) > 1 else 0
        if best < MIN_INLIERS or (second >= 5 and second > CLEAR_MARGIN * best):
            return None
        return CVMatch(best_name, best, second)
